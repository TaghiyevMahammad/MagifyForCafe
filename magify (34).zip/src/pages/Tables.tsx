import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, CheckSquare, Square, Pause, Play, X as CloseIcon, ChevronUp, ChevronDown, Receipt, Gamepad2, Clock, Sparkles, CreditCard } from 'lucide-react';
import TableCard from '../components/TableCard';
import { Table, ActiveSession, Device } from '../types';
import { useSessions } from '../contexts/SessionContext';
import { useTheme } from '../contexts/ThemeContext';
import { toast } from 'sonner';
import AddTableModal from '../components/AddTableModal';
import EditTableModal from '../components/EditTableModal';
import SessionModal from '../components/SessionModal';
import MultiPaymentModal from '../components/MultiPaymentModal';
import ConfirmModal from '../components/ConfirmModal';
import FinancialValue from '../components/FinancialValue';
import { apiFetch } from '../lib/api';
import { cn, formatCurrency } from '../lib/utils';

const Tables: React.FC = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { sessions, startSession, endSession, updateSession, loading: sessionsLoading, tick } = useSessions();
  const [tables, setTables] = useState<Table[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [tableSize, setTableSize] = useState<'small' | 'medium' | 'large'>(() => {
    return (localStorage.getItem('tableSize') as any) || 'medium';
  });
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [tableToEdit, setTableToEdit] = useState<Table | null>(null);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [tableToDelete, setTableToDelete] = useState<Table | null>(null);

  // Multi-selection state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedTableIds, setSelectedTableIds] = useState<number[]>([]);
  const [isDetailsExpanded, setIsDetailsExpanded] = useState(false);
  const [isMultiPaymentModalOpen, setIsMultiPaymentModalOpen] = useState(false);

  const fetchTablesAndDevices = useCallback(async () => {
    try {
      const [tablesRes, devicesRes] = await Promise.all([
        apiFetch('/api/tables'),
        apiFetch('/api/devices')
      ]);
      const tablesData = await tablesRes.json();
      const devicesData = await devicesRes.json();
      setTables(tablesData);
      setDevices(devicesData);
    } catch (error) {
      toast.error(t('error_update'));
    }
  }, [t]);

  useEffect(() => {
    fetchTablesAndDevices();
  }, [fetchTablesAndDevices]);

  const toggleTableSelection = useCallback((tableId: number) => {
    setSelectedTableIds(prev => 
      prev.includes(tableId) ? prev.filter(id => id !== tableId) : [...prev, tableId]
    );
  }, []);

  const handleTableClick = useCallback((e: React.MouseEvent, table: Table) => {
    if (isSelectionMode || e.shiftKey || e.ctrlKey || e.metaKey || selectedTableIds.length > 0) {
      toggleTableSelection(table.id);
    } else {
      setSelectedTable(table);
      setIsSessionModalOpen(true);
    }
  }, [isSelectionMode, selectedTableIds.length, toggleTableSelection]);

  const handleStartSession = useCallback(async (tableId: number, session: ActiveSession) => {
    try {
      await startSession(session);
      setIsSessionModalOpen(false);
      toast.success(t('success_add'));
    } catch (error) {
      toast.error(t('error_add'));
    }
  }, [startSession, t]);

  const handleEndSession = useCallback(async (tableId: number, transactionData: any) => {
    try {
      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transactionData)
      });
      
      if (res.ok) {
        await endSession(tableId);
        toast.success(t('success_update'));
      }
    } catch (error) {
      toast.error(t('error_update'));
    }
  }, [endSession, t]);

  const handleEditClick = useCallback((e: React.MouseEvent, table: Table) => {
    e.stopPropagation();
    setTableToEdit(table);
    setIsEditModalOpen(true);
  }, []);

  const handleDeleteClick = useCallback((e: React.MouseEvent, table: Table) => {
    e.stopPropagation();
    if (sessions[table.id]) {
      toast.error(t('error_delete'));
      return;
    }
    setTableToDelete(table);
    setIsDeleteModalOpen(true);
  }, [sessions, t]);

  const handlePauseClick = useCallback(async (e: React.MouseEvent, table: Table) => {
    e.stopPropagation();
    const session = sessions[table.id];
    if (!session || session.isPaused) return;

    const updatedSession: ActiveSession = {
      ...session,
      isPaused: true,
      pausedAt: Date.now()
    };
    await updateSession(updatedSession);
    toast.info(`${t('paused')}: ${table.name}`);
  }, [sessions, updateSession, t]);

  const handleResumeClick = useCallback(async (e: React.MouseEvent, table: Table) => {
    e.stopPropagation();
    const session = sessions[table.id];
    if (!session || !session.isPaused || !session.pausedAt) return;

    const now = Date.now();
    const pausedMinutes = Math.floor((now - session.pausedAt) / 60000);
    
    const updatedSession: ActiveSession = {
      ...session,
      isPaused: false,
      pausedAt: undefined,
      totalPausedMinutes: (session.totalPausedMinutes || 0) + pausedMinutes
    };
    await updateSession(updatedSession);
    toast.success(`${t('resume')}: ${table.name}`);
  }, [sessions, updateSession, t]);

  // Batch actions for multi-selection
  const handleBatchPause = async () => {
    const activeToPause = selectedTableIds
      .map(id => ({ id, session: sessions[id] }))
      .filter(item => item.session && !item.session.isPaused);

    if (activeToPause.length === 0) {
      toast.info(t('no_active_sessions_to_pause') || 'No active sessions to pause');
      return;
    }

    for (const item of activeToPause) {
      const updated: ActiveSession = {
        ...item.session,
        isPaused: true,
        pausedAt: Date.now()
      };
      await updateSession(updated);
    }
    toast.success(`${activeToPause.length} ${t('paused')}`);
  };

  const handleBatchResume = async () => {
    const pausedToResume = selectedTableIds
      .map(id => ({ id, session: sessions[id] }))
      .filter(item => item.session && item.session.isPaused && item.session.pausedAt);

    if (pausedToResume.length === 0) {
      toast.info(t('no_paused_sessions_to_resume') || 'No paused sessions to resume');
      return;
    }

    const now = Date.now();
    for (const item of pausedToResume) {
      const pausedMinutes = Math.floor((now - item.session.pausedAt!) / 60000);
      const updated: ActiveSession = {
        ...item.session,
        isPaused: false,
        pausedAt: undefined,
        totalPausedMinutes: (item.session.totalPausedMinutes || 0) + pausedMinutes
      };
      await updateSession(updated);
    }
    toast.success(`${pausedToResume.length} ${t('resume')}`);
  };

  const handleSelectAll = () => {
    setSelectedTableIds(tables.map(t => t.id));
  };

  const handleClearSelection = () => {
    setSelectedTableIds([]);
    setIsSelectionMode(false);
  };

  const handleBatchEndAndBill = useCallback(async (
    paymentData: {
      payment_type: 'cash' | 'card' | 'mixed' | 'unpaid';
      cash_amount: number;
      card_amount: number;
    },
    activeItems: Array<{
      table: Table;
      session: ActiveSession | null;
      timeCost: number;
      productCost: number;
      total: number;
      finalPayable: number;
      duration: number;
      isActive: boolean;
      isPaused: boolean;
      deviceName: string;
    }>
  ) => {
    const totalGrand = activeItems.reduce((acc, item) => acc + item.finalPayable, 0);
    let remainingCash = paymentData.cash_amount;

    for (let i = 0; i < activeItems.length; i++) {
      const item = activeItems[i];
      if (!item.session) continue;
      const isLast = i === activeItems.length - 1;
      let txCash = 0;
      let txCard = 0;

      if (paymentData.payment_type === 'cash') {
        txCash = item.finalPayable;
        txCard = 0;
      } else if (paymentData.payment_type === 'card') {
        txCash = 0;
        txCard = item.finalPayable;
      } else if (paymentData.payment_type === 'unpaid') {
        txCash = 0;
        txCard = 0;
      } else {
        // Mixed payment
        if (isLast) {
          txCash = Math.max(0, Math.min(item.finalPayable, remainingCash));
          txCard = Math.max(0, item.finalPayable - txCash);
        } else {
          const ratio = totalGrand > 0 ? (item.finalPayable / totalGrand) : 0;
          txCash = Math.min(item.finalPayable, Math.round(paymentData.cash_amount * ratio * 100) / 100);
          txCard = Math.max(0, item.finalPayable - txCash);
          remainingCash -= txCash;
        }
      }

      const txPayload = {
        table_id: item.table.id,
        table_name: item.table.name,
        ps_type: item.deviceName,
        device_id: item.session.deviceId,
        start_time: new Date(item.session.startTime).toISOString(),
        end_time: new Date().toISOString(),
        duration_minutes: item.duration,
        time_cost: item.timeCost,
        product_cost: item.productCost,
        total_cost: item.finalPayable,
        products_json: JSON.stringify(item.session.products || []),
        extensions_json: JSON.stringify(item.session.extensions || []),
        payment_type: paymentData.payment_type,
        cash_amount: txCash,
        card_amount: txCard
      };

      const res = await apiFetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(txPayload)
      });

      if (res.ok) {
        await endSession(item.table.id);
      }
    }

    toast.success(t('batch_checkout_success'));
    setSelectedTableIds([]);
    setIsSelectionMode(false);
  }, [endSession, t]);

  const handleSizeChange = (size: 'small' | 'medium' | 'large') => {
    setTableSize(size);
    localStorage.setItem('tableSize', size);
  };

  const getGridClass = () => {
    switch (tableSize) {
      case 'small': return "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-3 sm:gap-4";
      case 'large': return "grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8";
      default: return "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6";
    }
  };

  const confirmDelete = async () => {
    if (!tableToDelete) return;
    try {
      const res = await apiFetch(`/api/tables/${tableToDelete.id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setTables(prev => prev.filter(t => t.id !== tableToDelete.id));
        toast.success(t('success_delete'));
        setIsDeleteModalOpen(false);
        setTableToDelete(null);
      } else {
        toast.error(t('error_delete'));
      }
    } catch (error) {
      toast.error(t('error_delete'));
    }
  };

  const kabinetler = tables.filter(t => t.type === 'kabinet');
  const standardTables = tables.filter(t => t.type === 'table');

  const selectedTables = tables.filter(t => selectedTableIds.includes(t.id));
  const selectedActiveCount = selectedTables.filter(t => !!sessions[t.id]).length;
  const selectedAvailableCount = selectedTables.length - selectedActiveCount;

  const selectedTablesWithDetails = useMemo(() => {
    return selectedTableIds.map(id => {
      const table = tables.find(t => t.id === id);
      const session = sessions[id];
      if (!table) return null;

      if (!session) {
        return {
          table,
          session: null,
          timeCost: 0,
          productCost: 0,
          total: 0,
          finalPayable: 0,
          duration: 0,
          isActive: false,
          isPaused: false,
          deviceName: '—'
        };
      }

      const now = Date.now();
      const totalPausedMs = (session.totalPausedMinutes || 0) * 60000;
      let elapsedMs = now - session.startTime - totalPausedMs;

      if (session.isPaused && session.pausedAt) {
        const currentPauseMs = now - session.pausedAt;
        elapsedMs -= currentPauseMs;
      }

      const elapsed = Math.floor(elapsedMs / 60000);
      const manualAddedMinutes = session.prepaidMinutes || 0;

      const totalIncludedMinutes = (session.products || []).reduce((acc, p) => {
        if (p.is_set && p.included_minutes) {
          return acc + (p.included_minutes * p.quantity);
        }
        return acc;
      }, 0);

      let duration = 0;
      let billableMinutes = 0;

      if (session.type === 'fixed' || session.type === 'amount') {
        duration = session.durationMinutes || 0;
        billableMinutes = Math.max(0, duration - totalIncludedMinutes);
      } else {
        const totalUsage = elapsed + manualAddedMinutes;
        duration = totalUsage;
        billableMinutes = Math.max(0, totalUsage - totalIncludedMinutes);
      }

      const device = devices.find(d => d.id === session.deviceId);
      const hourlyPrice = device ? device.hourly_price : (table.hourly_price || 0);

      const timeCost = (billableMinutes / 60) * hourlyPrice;
      const productCost = (session.products || []).reduce((acc, p) => acc + (p.price * p.quantity), 0);

      let total = timeCost + productCost;
      let finalPayable = total;

      if (session.billingMode === 'depozit' && session.depositAmount) {
        finalPayable = Math.max(total, session.depositAmount);
      }

      return {
        table,
        session,
        timeCost,
        productCost,
        total,
        finalPayable,
        duration,
        isActive: true,
        isPaused: !!session.isPaused,
        deviceName: device?.name || session.psType || '—'
      };
    }).filter(Boolean) as Array<{
      table: Table;
      session: ActiveSession | null;
      timeCost: number;
      productCost: number;
      total: number;
      finalPayable: number;
      duration: number;
      isActive: boolean;
      isPaused: boolean;
      deviceName: string;
    }>;
  }, [selectedTableIds, tables, sessions, devices, tick]);

  const totalCommonBill = useMemo(() => {
    return selectedTablesWithDetails.reduce((acc, item) => acc + item.finalPayable, 0);
  }, [selectedTablesWithDetails]);

  const totalTimeCost = useMemo(() => {
    return selectedTablesWithDetails.reduce((acc, item) => acc + item.timeCost, 0);
  }, [selectedTablesWithDetails]);

  const totalProductCost = useMemo(() => {
    return selectedTablesWithDetails.reduce((acc, item) => acc + item.productCost, 0);
  }, [selectedTablesWithDetails]);

  if (sessionsLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-12 font-sans pb-20">
      <ConfirmModal 
        isOpen={isDeleteModalOpen}
        title={t('delete')}
        message={t('confirm_delete_table')}
        onConfirm={confirmDelete}
        onCancel={() => setIsDeleteModalOpen(false)}
      />
      <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 sm:gap-6">
        <div className="space-y-1">
          <h1 className={cn(
            "text-3xl sm:text-4xl font-bold tracking-tighter",
            theme === 'dark' ? "text-white" : "text-slate-900"
          )}>{t('tables')}</h1>
          <p className="text-sm sm:text-base text-zinc-500 font-medium">{t('manage_tables_desc')}.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 sm:gap-4 w-full sm:w-auto">
          {/* Multi-selection toggle */}
          <button
            onClick={() => {
              if (isSelectionMode && selectedTableIds.length > 0) {
                handleClearSelection();
              } else {
                setIsSelectionMode(!isSelectionMode);
              }
            }}
            className={cn(
              "flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all border",
              isSelectionMode || selectedTableIds.length > 0
                ? "bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-500/30"
                : (theme === 'dark' ? "bg-white/5 border-white/10 text-zinc-300 hover:text-white hover:bg-white/10" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200")
            )}
          >
            {isSelectionMode || selectedTableIds.length > 0 ? (
              <CheckSquare className="w-4 h-4 text-white" />
            ) : (
              <Square className="w-4 h-4 text-zinc-400" />
            )}
            <span>{t('multi_select') || 'Multi-Select'}</span>
          </button>

          <div className={cn(
            "flex items-center gap-2 p-1 rounded-2xl border w-full sm:w-auto",
            theme === 'dark' ? "bg-white/5 border-white/5" : "bg-slate-100 border-slate-200"
          )}>
            {(['small', 'medium', 'large'] as const).map((size) => (
              <button
                key={size}
                onClick={() => handleSizeChange(size)}
                className={cn(
                  "flex-1 sm:flex-none px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-colors duration-150",
                  tableSize === size 
                    ? theme === 'dark' ? "bg-white text-black" : "bg-white text-slate-900 shadow-sm"
                    : "text-zinc-500 hover:text-zinc-300"
                )}
              >
                {t(size)}
              </button>
            ))}
          </div>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className={cn(
              "flex items-center justify-center gap-2 px-5 sm:px-6 py-2.5 sm:py-3 rounded-2xl font-bold text-xs sm:text-sm uppercase tracking-wider transition-colors duration-150 w-full sm:w-auto",
              theme === 'dark' 
                ? "bg-white text-black" 
                : "bg-slate-900 text-white shadow-sm"
            )}
          >
            <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
            {t('add_table')}
          </button>
        </div>
      </header>

      <div className="space-y-16">
        {kabinetler.length > 0 && (
          <section>
            <div className="flex items-center gap-3 mb-8">
              <div className={cn(
                "w-1.5 h-8 rounded-full",
                theme === 'dark' ? "bg-white" : "bg-slate-900"
              )} />
              <h2 className={cn(
                "text-2xl font-bold tracking-tight",
                theme === 'dark' ? "text-white" : "text-slate-900"
              )}>{t('kabinetler')}</h2>
            </div>
            <div className={getGridClass()}>
              {kabinetler.map(table => (
                <TableCard 
                  key={table.id} 
                  table={table} 
                  size={tableSize}
                  session={sessions[table.id]}
                  isSelected={selectedTableIds.includes(table.id)}
                  onClick={(e: any) => handleTableClick(e || window.event, table)}
                  onEdit={(e) => handleEditClick(e, table)}
                  onDelete={(e) => handleDeleteClick(e, table)}
                  onPause={(e) => handlePauseClick(e, table)}
                  onResume={(e) => handleResumeClick(e, table)}
                />
              ))}
            </div>
          </section>
        )}

        {standardTables.length > 0 && (
          <section>
            <div className="flex items-center gap-3 mb-8">
              <div className={cn(
                "w-1.5 h-8 rounded-full",
                theme === 'dark' ? "bg-white/20" : "bg-slate-200"
              )} />
              <h2 className={cn(
                "text-2xl font-bold tracking-tight",
                theme === 'dark' ? "text-white" : "text-slate-900"
              )}>{t('standard_tables')}</h2>
            </div>
            <div className={getGridClass()}>
              {standardTables.map(table => (
                <TableCard 
                  key={table.id} 
                  table={table} 
                  size={tableSize}
                  session={sessions[table.id]}
                  isSelected={selectedTableIds.includes(table.id)}
                  onClick={(e: any) => handleTableClick(e || window.event, table)}
                  onEdit={(e) => handleEditClick(e, table)}
                  onDelete={(e) => handleDeleteClick(e, table)}
                  onPause={(e) => handlePauseClick(e, table)}
                  onResume={(e) => handleResumeClick(e, table)}
                />
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Multi-Selection Dock Toolbar with Common Bill */}
      {selectedTableIds.length > 0 && (
        <div className="fixed bottom-3 sm:bottom-6 inset-x-2 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 z-40 w-auto max-w-[96vw] xl:max-w-6xl">
          {/* Expanded Breakdown Drawer */}
          {isDetailsExpanded && (
            <div className={cn(
              "mb-2.5 sm:mb-3 p-3.5 sm:p-4 rounded-2xl border shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-bottom-3 duration-200 max-h-60 sm:max-h-72 overflow-y-auto",
              theme === 'dark'
                ? "bg-[#141417]/95 border-white/10 text-white"
                : "bg-white/95 border-slate-200 text-slate-900 shadow-slate-300"
            )}>
              <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-500 shrink-0" />
                  <h4 className="text-xs font-bold uppercase tracking-wider">{t('individual_bills')}</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 font-bold">
                    {selectedTablesWithDetails.length} {t('tables').toLowerCase()}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 sm:gap-2">
                  {selectedActiveCount > 0 && (
                    <button
                      onClick={() => setIsMultiPaymentModalOpen(true)}
                      className="flex items-center gap-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-500 px-2.5 py-1 rounded-lg shadow-sm transition-colors cursor-pointer"
                    >
                      <CreditCard className="w-3 h-3" />
                      <span>{t('end_and_bill_together')}</span>
                    </button>
                  )}
                  <button
                    onClick={() => setIsDetailsExpanded(false)}
                    className="text-xs text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-white/5 cursor-pointer"
                  >
                    <CloseIcon className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 sm:gap-2.5">
                {selectedTablesWithDetails.map(item => (
                  <div
                    key={item.table.id}
                    className={cn(
                      "p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between transition-all",
                      theme === 'dark' ? "bg-white/5 border-white/5" : "bg-slate-50 border-slate-200"
                    )}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="min-w-0">
                        <p className="font-bold text-xs truncate">{item.table.name}</p>
                        <p className="text-[10px] text-zinc-400 truncate">
                          {item.table.type === 'kabinet' ? t('kabinet') : t('table')} • {item.deviceName}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleTableSelection(item.table.id);
                        }}
                        className="text-zinc-500 hover:text-rose-400 p-0.5 rounded transition-colors shrink-0"
                        title={t('cancel')}
                      >
                        <CloseIcon className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-end justify-between pt-2 border-t border-white/5">
                      <div className="text-[10px] text-zinc-400">
                        {item.isActive ? (
                          <span>
                            {t('time')}: <FinancialValue>{formatCurrency(item.timeCost)}</FinancialValue>
                            {item.productCost > 0 && ` + ${t('products')}: `}
                            {item.productCost > 0 && <FinancialValue>{formatCurrency(item.productCost)}</FinancialValue>}
                          </span>
                        ) : (
                          <span className="text-emerald-400 font-medium">{t('free_table')}</span>
                        )}
                      </div>
                      <div className="text-right shrink-0 pl-1">
                        <span className="text-xs font-black font-mono text-emerald-400">
                          {item.isActive ? (
                            <FinancialValue>{formatCurrency(item.finalPayable)}</FinancialValue>
                          ) : (
                            formatCurrency(0)
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Main Bottom Floating Bar */}
          <div className={cn(
            "p-2.5 sm:px-4 sm:py-3 rounded-2xl md:rounded-full border shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-bottom-5 duration-200 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5 md:gap-3.5",
            theme === 'dark' 
              ? "bg-[#18181b]/95 border-white/15 text-white" 
              : "bg-white/95 border-slate-200 text-slate-900 shadow-slate-300"
          )}>
            {/* Left: Count, Active/Free summary, and Optional Table Pills */}
            <div className="flex items-center justify-between md:justify-start gap-2.5 sm:gap-3 shrink-0">
              <div className="flex items-center gap-2 shrink-0">
                <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-blue-600 text-white font-bold text-xs shadow-sm shadow-blue-600/30">
                  {selectedTableIds.length}
                </span>
                <div className="text-xs">
                  <p className="font-bold whitespace-nowrap leading-tight">
                    {selectedTableIds.length} {t('selected_tables_count')}
                  </p>
                  <p className="text-[10px] text-zinc-400 whitespace-nowrap leading-tight">
                    {selectedActiveCount} {t('active')}, {selectedAvailableCount} {t('free_table')}
                  </p>
                </div>
              </div>

              {/* Individual Table Amounts Pills (Desktop) */}
              <div className="hidden 2xl:flex items-center gap-1.5 overflow-x-auto max-w-[220px] py-0.5 scrollbar-none">
                {selectedTablesWithDetails.slice(0, 3).map(item => (
                  <button
                    key={item.table.id}
                    onClick={() => {
                      setSelectedTable(item.table);
                      setIsSessionModalOpen(true);
                    }}
                    className={cn(
                      "flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-semibold shrink-0 border transition-all cursor-pointer",
                      item.isActive
                        ? (theme === 'dark' ? "bg-white/10 border-white/10 text-zinc-200" : "bg-slate-100 border-slate-200 text-slate-800")
                        : (theme === 'dark' ? "bg-white/5 border-white/5 text-zinc-500" : "bg-slate-50 border-slate-100 text-slate-400")
                    )}
                  >
                    <span className="truncate max-w-[55px]">{item.table.name}:</span>
                    <span className={cn("font-mono font-bold", item.isActive ? "text-emerald-400" : "text-zinc-500")}>
                      {item.isActive ? <FinancialValue>{formatCurrency(item.finalPayable)}</FinancialValue> : t('free_table')}
                    </span>
                  </button>
                ))}
              </div>

              {/* Mobile Quick Deselect Button */}
              <button
                onClick={handleClearSelection}
                className="md:hidden p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title={t('clear_selection')}
              >
                <CloseIcon className="w-4 h-4" />
              </button>
            </div>

            {/* Middle Section: Common Bill (Ümumi Hesab) */}
            <div className={cn(
              "flex items-center justify-between gap-2.5 px-3 py-1.5 rounded-xl border shrink-0",
              theme === 'dark' ? "bg-emerald-950/30 border-emerald-500/30" : "bg-emerald-50 border-emerald-200"
            )}>
              <div className="flex items-center gap-2">
                <div className="p-1 sm:p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
                  <Receipt className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-widest font-black text-emerald-500 leading-tight">
                    {t('common_bill')}
                  </p>
                  <p className="text-sm sm:text-base font-black font-mono tracking-tight text-emerald-400 leading-tight">
                    <FinancialValue>{formatCurrency(totalCommonBill)}</FinancialValue>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsDetailsExpanded(!isDetailsExpanded)}
                className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 hover:text-emerald-300 px-2 py-1 rounded-lg hover:bg-emerald-500/10 transition-colors cursor-pointer whitespace-nowrap ml-1"
                title={isDetailsExpanded ? t('hide_details') : t('view_details')}
              >
                <span>{isDetailsExpanded ? t('hide_details') : t('individual_bills')}</span>
                {isDetailsExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Right: Actions */}
            <div className="flex flex-wrap sm:flex-nowrap items-center justify-between sm:justify-end gap-1.5">
              <button
                onClick={() => {
                  if (selectedActiveCount === 0) {
                    toast.error(t('no_active_sessions_to_bill'));
                    return;
                  }
                  setIsMultiPaymentModalOpen(true);
                }}
                disabled={selectedActiveCount === 0}
                className={cn(
                  "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-white text-xs font-bold transition-all cursor-pointer whitespace-nowrap",
                  selectedActiveCount > 0
                    ? "bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30"
                    : "bg-zinc-700 opacity-60 cursor-not-allowed"
                )}
                title={t('end_and_bill_together')}
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>{t('end_and_bill_together')}</span>
              </button>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleBatchPause}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-500 border border-amber-500/30 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
                  title={t('batch_pause')}
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span className="hidden xl:inline">{t('batch_pause')}</span>
                  <span className="xl:hidden">{t('pause')}</span>
                </button>

                <button
                  onClick={handleBatchResume}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-500 border border-emerald-500/30 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
                  title={t('batch_resume')}
                >
                  <Play className="w-3.5 h-3.5" />
                  <span className="hidden xl:inline">{t('batch_resume')}</span>
                  <span className="xl:hidden">{t('resume')}</span>
                </button>

                <button
                  onClick={handleSelectAll}
                  className={cn(
                    "px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-colors cursor-pointer whitespace-nowrap",
                    theme === 'dark' ? "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-300" : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700"
                  )}
                  title={t('select_all')}
                >
                  {t('select_all')}
                </button>

                <button
                  onClick={handleClearSelection}
                  className="hidden md:flex p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                  title={t('clear_selection')}
                >
                  <CloseIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isAddModalOpen && (
        <AddTableModal 
          onClose={() => setIsAddModalOpen(false)} 
          onSuccess={fetchTablesAndDevices} 
        />
      )}

      {isEditModalOpen && tableToEdit && (
        <EditTableModal 
          table={tableToEdit}
          onClose={() => setIsEditModalOpen(false)} 
          onSuccess={fetchTablesAndDevices} 
        />
      )}

      {isSessionModalOpen && selectedTable && (
        <SessionModal 
          table={selectedTable}
          session={sessions[selectedTable.id]}
          onClose={() => {
            setIsSessionModalOpen(false);
          }}
          onStart={(session) => handleStartSession(selectedTable.id, session)}
          onEnd={(tx) => handleEndSession(selectedTable.id, tx)}
        />
      )}

      {isMultiPaymentModalOpen && (
        <MultiPaymentModal 
          items={selectedTablesWithDetails}
          onClose={() => setIsMultiPaymentModalOpen(false)}
          onConfirm={handleBatchEndAndBill}
        />
      )}
    </div>
  );
};

export default Tables;
