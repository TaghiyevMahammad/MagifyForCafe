import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { History, Calendar, Download, Filter, Eye, EyeOff, ChevronDown, ChevronUp, ScrollText, Trash2 } from 'lucide-react';
import { Transaction, Device } from '../types';
import { formatCurrency, cn, formatDateTime, getBakuDateString, convertBakuToUTC } from '../lib/utils';
import { toast } from 'sonner';
import { useTheme } from '../contexts/ThemeContext';
import FinancialValue from '../components/FinancialValue';
import { useFinancialVisibility } from '../contexts/FinancialVisibilityContext';
import { apiFetch } from '../lib/api';
import ActionPasswordModal from '../components/ActionPasswordModal';
import ReportPasswordModal from '../components/ReportPasswordModal';
import ClearHistoryModal from '../components/ClearHistoryModal';
import ConfirmModal from '../components/ConfirmModal';

const SeparateReports: React.FC = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { isVisible, hide } = useFinancialVisibility();
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isClearRangeModalOpen, setIsClearRangeModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [txToDelete, setTxToDelete] = useState<number | null>(null);
  const [pendingAction, setPendingAction] = useState<{ type: 'clear' | 'delete', data?: any } | null>(null);
  const [expandedTx, setExpandedTx] = useState<number | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [startDate, setStartDate] = useState(() => getBakuDateString(new Date()));
  const [startTime, setStartTime] = useState('09:00');
  const [endDate, setEndDate] = useState(() => {
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
    return getBakuDateString(tomorrow);
  });
  const [endTime, setEndTime] = useState('09:00');

  const [stats, setStats] = useState({
    total: 0,
    daily: 0,
    monthly: 0,
    unpaidCount: 0
  });

  useEffect(() => {
    fetchDevices();
  }, []);

  useEffect(() => {
    fetchTransactions();
  }, [startDate, startTime, endDate, endTime, devices]);

  const fetchDevices = async () => {
    try {
      const res = await apiFetch('/api/devices');
      const data = await res.json();
      setDevices(data);
    } catch (error) {
      console.error('Error fetching devices:', error);
    }
  };

  const fetchTransactions = async () => {
    try {
      const params = new URLSearchParams();
      if (startDate) {
        const utcStart = convertBakuToUTC(startDate, startTime);
        if (utcStart) params.append('startDate', utcStart);
      }
      if (endDate) {
        const utcEnd = convertBakuToUTC(endDate, endTime);
        if (utcEnd) {
          const utcEndFinal = utcEnd.substring(0, 16) + ':59';
          params.append('endDate', utcEndFinal);
        }
      }

      const res = await apiFetch(`/api/transactions?${params.toString()}&reportType=separate`);
      const allTx: Transaction[] = await res.json();
      
      // Filter for transactions that have a device marked as separate_report
      const separateDeviceIds = devices.filter(d => Boolean(d.separate_report)).map(d => d.id);
      const separateDeviceNames = devices.filter(d => Boolean(d.separate_report)).map(d => d.name.trim().toLowerCase());

      const filtered = allTx.filter(tx => 
        (tx.device_id && separateDeviceIds.includes(tx.device_id)) || 
        (tx.ps_type && separateDeviceNames.includes(tx.ps_type.trim().toLowerCase()))
      );

      setTransactions(filtered);

      // Calculate stats based on time_cost only
      const nowBaku = new Date(new Date().getTime() + (4 * 60 * 60 * 1000));
      const todayStr = nowBaku.toISOString().split('T')[0];
      const monthStr = todayStr.substring(0, 7);

      let total = 0;
      let daily = 0;
      let monthly = 0;
      let unpaidCount = 0;

      filtered.forEach(tx => {
        if (tx.payment_type === 'unpaid') {
          unpaidCount++;
          return;
        }

        const txBaku = new Date(new Date(tx.created_at).getTime() + (4 * 60 * 60 * 1000));
        const txDateStr = txBaku.toISOString().split('T')[0];
        
        total += tx.time_cost;
        if (txDateStr === todayStr) daily += tx.time_cost;
        if (txDateStr.startsWith(monthStr)) monthly += tx.time_cost;
      });

      setStats({ total, daily, monthly, unpaidCount });

    } catch (error) {
      console.error('Error fetching transactions:', error);
      toast.error(t('error_update'));
    }
  };

  const getFilterDates = (type: 'today' | 'week' | 'month') => {
    const nowBaku = new Date(new Date().getTime() + (4 * 60 * 60 * 1000));
    const todayStr = nowBaku.toISOString().split('T')[0];
    
    if (type === 'today') return { start: todayStr, end: todayStr };
    
    if (type === 'week') {
      const day = nowBaku.getUTCDay();
      const dayOffset = day === 0 ? 6 : day - 1;
      const startOfThisWeek = new Date(nowBaku);
      startOfThisWeek.setUTCDate(nowBaku.getUTCDate() - dayOffset);
      return { start: startOfThisWeek.toISOString().split('T')[0], end: todayStr };
    }
    
    if (type === 'month') {
      const startOfThisMonth = new Date(nowBaku);
      startOfThisMonth.setUTCDate(1);
      return { start: startOfThisMonth.toISOString().split('T')[0], end: todayStr };
    }
    
    return { start: todayStr, end: todayStr };
  };

  const isFilterActive = (type: 'today' | 'week' | 'month') => {
    const { start, end } = getFilterDates(type);
    return startDate === start && endDate === end && startTime === '00:00' && endTime === '23:59';
  };

  const setQuickFilter = (type: 'today' | 'week' | 'month') => {
    const { start, end } = getFilterDates(type);
    setStartDate(start);
    setStartTime('00:00');
    setEndDate(end);
    setEndTime('23:59');
  };

  const handlePasswordSuccess = () => {
    if (!pendingAction) return;
    if (pendingAction.type === 'clear') {
      setIsClearRangeModalOpen(true);
    } else if (pendingAction.type === 'delete') {
      setTxToDelete(pendingAction.data);
      setIsDeleteModalOpen(true);
    }
    setPendingAction(null);
  };

  const handleClearHistoryClick = () => {
    setPendingAction({ type: 'clear' });
    setIsPasswordModalOpen(true);
  };

  const handleDeleteClick = (id: number) => {
    setPendingAction({ type: 'delete', data: id });
    setIsPasswordModalOpen(true);
  };

  const confirmDelete = async () => {
    if (!txToDelete) return;
    try {
      await apiFetch(`/api/transactions/${txToDelete}?reportType=separate`, { method: 'DELETE' });
      toast.success(t('success_delete'));
      fetchTransactions();
      setIsDeleteModalOpen(false);
    } catch (error) {
      toast.error(t('error_delete'));
    }
  };

  const confirmClear = async (startDate?: string, startTime?: string, endDate?: string, endTime?: string) => {
    try {
      const params = new URLSearchParams();
      if (startDate) {
        const utcStart = convertBakuToUTC(startDate, startTime || '00:00');
        if (utcStart) params.append('startDate', utcStart);
      }
      if (endDate) {
        const utcEnd = convertBakuToUTC(endDate, endTime || '23:59');
        if (utcEnd) {
          const utcEndFinal = utcEnd.substring(0, 16) + ':59';
          params.append('endDate', utcEndFinal);
        }
      }

      await apiFetch(`/api/transactions?${params.toString()}&reportType=separate`, { method: 'DELETE' });
      toast.success(t('success_delete'));
      fetchTransactions();
      setIsClearRangeModalOpen(false);
    } catch (error) {
      toast.error(t('error_delete'));
    }
  };

  const clearFilters = () => {
    setStartDate('');
    setStartTime('00:00');
    setEndDate('');
    setEndTime('23:59');
  };

  const SummaryCard = ({ title, value }: { title: string, value: number }) => (
    <div className={cn(
      "border rounded-3xl p-6 transition-all shadow-sm",
      theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200"
    )}>
      <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">{title}</p>
      <p className={cn("text-2xl font-black tracking-tighter", theme === 'dark' ? "text-white" : "text-slate-900")}>
        <FinancialValue>{formatCurrency(value)}</FinancialValue>
      </p>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {isPasswordModalOpen && (
        <ActionPasswordModal 
          isOpen={isPasswordModalOpen}
          onClose={() => {
            setIsPasswordModalOpen(false);
            setPendingAction(null);
          }}
          onConfirm={handlePasswordSuccess}
        />
      )}
      {isReportModalOpen && (
        <ReportPasswordModal 
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}
      {isClearRangeModalOpen && (
        <ClearHistoryModal 
          isOpen={isClearRangeModalOpen}
          onClose={() => setIsClearRangeModalOpen(false)}
          onConfirm={confirmClear}
        />
      )}
      {isDeleteModalOpen && (
        <ConfirmModal 
          isOpen={isDeleteModalOpen}
          title={t('delete')}
          message={t('confirm_delete')}
          onConfirm={confirmDelete}
          onCancel={() => setIsDeleteModalOpen(false)}
        />
      )}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className={cn("text-3xl font-bold tracking-tight", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('separate_reports')}</h1>
          <p className="text-zinc-400 mt-1">{t('manage_reports_desc')}</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleClearHistoryClick}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest transition-all shadow-sm",
              theme === 'dark' ? "bg-rose-500/10 text-rose-500 border border-rose-500/20 hover:bg-rose-500/20" : "bg-rose-50 text-rose-600 border border-rose-100 hover:bg-rose-100"
            )}
          >
            <Trash2 className="w-5 h-5" />
            <span>{t('clear_history')}</span>
          </button>
          <button
            onClick={() => isVisible ? hide() : setIsReportModalOpen(true)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest transition-all shadow-sm",
              isVisible 
                ? "bg-rose-500/10 text-rose-500 border border-rose-500/20 hover:bg-rose-500/20" 
                : "bg-blue-500/10 text-blue-500 border border-blue-500/20 hover:bg-blue-500/20"
            )}
          >
            {isVisible ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            {isVisible ? t('hide') : t('reveal')}
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <SummaryCard title={t('today')} value={stats.daily} />
        <SummaryCard title={t('this_month')} value={stats.monthly} />
        <SummaryCard title={t('total')} value={stats.total} />
        <div className={cn(
          "border rounded-3xl p-6 transition-all shadow-sm",
          theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200"
        )}>
          <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">{t('unpaid_closures')}</p>
          <p className={cn("text-2xl font-black tracking-tighter", stats.unpaidCount > 0 ? "text-rose-500" : (theme === 'dark' ? "text-white" : "text-slate-900"))}>
            {stats.unpaidCount}
          </p>
        </div>
      </div>

      <div className={cn(
        "border rounded-3xl p-6 transition-all shadow-sm",
        theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200"
      )}>
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex flex-wrap items-center gap-2">
            <button 
              onClick={() => setQuickFilter('today')}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-bold transition-all",
                isFilterActive('today')
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20"
                  : (theme === 'dark' ? "bg-white/5 text-zinc-400 hover:bg-white/10 hover:text-white" : "bg-slate-50 text-slate-500 hover:bg-slate-100")
              )}
            >
              {t('today')}
            </button>
            <button 
              onClick={() => setQuickFilter('week')}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-bold transition-all",
                isFilterActive('week')
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20"
                  : (theme === 'dark' ? "bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white" : "bg-slate-50 text-slate-500 hover:bg-slate-100")
              )}
            >
              {t('this_week')}
            </button>
            <button 
              onClick={() => setQuickFilter('month')}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-bold transition-all",
                isFilterActive('month')
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20"
                  : (theme === 'dark' ? "bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white" : "bg-slate-50 text-slate-500 hover:bg-slate-100")
              )}
            >
              {t('this_month')}
            </button>
            <button 
              onClick={clearFilters}
              className={cn(
                "px-4 py-2 text-sm font-bold transition-colors",
                theme === 'dark' ? "text-zinc-500 hover:text-white" : "text-slate-400 hover:text-slate-900"
              )}
            >
              {t('clear_filters')}
            </button>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-4">
            <div className={cn(
              "flex items-center gap-2 p-2 rounded-xl border transition-all",
              theme === 'dark' ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
            )}>
              <input 
                type="date" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className={cn("bg-transparent text-xs font-bold focus:outline-none", theme === 'dark' ? "text-white" : "text-slate-900")}
              />
              <div className={cn("w-px h-3", theme === 'dark' ? "bg-white/10" : "bg-slate-200")} />
              <input 
                type="time" 
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className={cn("bg-transparent text-xs font-bold focus:outline-none", theme === 'dark' ? "text-white" : "text-slate-900")}
              />
            </div>
            <span className="text-zinc-500">to</span>
            <div className={cn(
              "flex items-center gap-2 p-2 rounded-xl border transition-all",
              theme === 'dark' ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
            )}>
              <input 
                type="date" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className={cn("bg-transparent text-xs font-bold focus:outline-none", theme === 'dark' ? "text-white" : "text-slate-900")}
              />
              <div className={cn("w-px h-3", theme === 'dark' ? "bg-white/10" : "bg-slate-200")} />
              <input 
                type="time" 
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className={cn("bg-transparent text-xs font-bold focus:outline-none", theme === 'dark' ? "text-white" : "text-slate-900")}
              />
            </div>
          </div>
        </div>
      </div>

      <div className={cn(
        "border rounded-3xl overflow-hidden shadow-sm transition-all",
        theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200"
      )}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={cn("border-b", theme === 'dark' ? "border-white/5" : "border-slate-100")}>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('date')}</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('table')}</th>
                 <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('ps_type')}</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('device_income')}</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500 text-right">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className={cn("divide-y", theme === 'dark' ? "divide-white/5" : "divide-slate-100")}>
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-zinc-500 italic">
                    {t('no_activity')}
                  </td>
                </tr>
              ) : (
                transactions.map(tx => (
                  <React.Fragment key={tx.id}>
                    <tr 
                      className={cn(
                        "transition-colors group cursor-pointer",
                        theme === 'dark' ? "hover:bg-white/5" : "hover:bg-slate-50"
                      )}
                      onClick={() => setExpandedTx(expandedTx === tx.id ? null : tx.id)}
                    >
                      <td className="px-6 py-4 text-xs text-zinc-400 font-medium">
                        <div className="flex items-center gap-2">
                          {expandedTx === tx.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          {formatDateTime(tx.created_at)}
                        </div>
                      </td>
                      <td className={cn("px-6 py-4 font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{tx.table_name}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 bg-blue-600/10 text-blue-500 rounded-md text-[10px] font-bold uppercase tracking-tighter">
                            {tx.ps_type || '-'}
                          </span>
                        </div>
                      </td>
                      <td className={cn("px-6 py-4 font-black", tx.payment_type === 'unpaid' ? "text-rose-500" : "text-emerald-500")}>
                        <FinancialValue>
                          {tx.payment_type === 'unpaid' ? t('unpaid_closed') : formatCurrency(tx.time_cost)}
                        </FinancialValue>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteClick(tx.id);
                          }}
                          className="p-2 text-zinc-500 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                    {expandedTx === tx.id && (
                      <tr className={theme === 'dark' ? "bg-white/[0.02]" : "bg-slate-50/30"}>
                        <td colSpan={5} className="px-12 py-6">
                          <div className="space-y-6">
                            <div className="flex items-center gap-6 pb-4 border-b border-white/5">
                              <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{t('device')}</span>
                                <span className={cn("text-xs font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{tx.ps_type}</span>
                              </div>
                              <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{t('start_time')}</span>
                                <span className={cn("text-xs font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{formatDateTime(tx.start_time)}</span>
                              </div>
                              <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{t('end_time')}</span>
                                <span className={cn("text-xs font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{formatDateTime(tx.end_time)}</span>
                              </div>
                              <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">{t('duration')}</span>
                                <span className={cn("text-xs font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{tx.duration_minutes} {t('minutes')}</span>
                              </div>
                            </div>

                            {/* Extensions Block */}
                            {tx.extensions_json && JSON.parse(tx.extensions_json).length > 0 && (
                              <div className="space-y-4">
                                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{t('vaxt_elaveleri')}</h4>
                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                  {(() => {
                                    const summary: Record<number, number> = {};
                                    JSON.parse(tx.extensions_json).forEach((ext: any) => {
                                      summary[ext.minutes] = (summary[ext.minutes] || 0) + 1;
                                    });
                                    return Object.entries(summary).sort((a, b) => parseInt(a[0]) - parseInt(b[0])).map(([mins, count]) => {
                                      const isNegative = parseInt(mins) < 0;
                                      const absMins = Math.abs(parseInt(mins));
                                      return (
                                        <div key={mins} className={cn(
                                          "flex justify-between items-center p-4 rounded-2xl border transition-all",
                                          theme === 'dark' 
                                            ? (isNegative ? "bg-rose-500/5 border-rose-500/10" : "bg-amber-500/5 border-amber-500/10") 
                                            : (isNegative ? "bg-rose-50 border-rose-100 shadow-sm" : "bg-amber-50 border-amber-100 shadow-sm")
                                        )}>
                                          <div className="flex items-center gap-2">
                                            <div className={cn(
                                              "w-2 h-2 rounded-full animate-pulse",
                                              isNegative ? "bg-rose-500" : "bg-amber-500"
                                            )} />
                                            <span className={cn(
                                              "text-xs font-bold",
                                              theme === 'dark' 
                                                ? (isNegative ? "text-rose-500" : "text-amber-500") 
                                                : (isNegative ? "text-rose-600" : "text-amber-600")
                                            )}>
                                              {isNegative ? '-' : '+'}{absMins >= 60 ? `${Math.floor(absMins/60)}h` : `${absMins}m`} {t('minutes_label')}
                                            </span>
                                          </div>
                                          <span className={cn(
                                            "text-[10px] font-black px-2 py-1 rounded-lg",
                                            isNegative ? "text-rose-500 bg-rose-500/10" : "text-amber-500 bg-amber-500/10"
                                          )}>
                                            {count} {t('times')}
                                          </span>
                                        </div>
                                      );
                                    });
                                  })()}
                                </div>
                              </div>
                            )}

                            <div className="space-y-4">
                              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{t('products')}</h4>
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                                {JSON.parse(tx.products_json || '[]').map((p: any, i: number) => (
                                  <div key={i} className={cn(
                                    "flex justify-between items-center p-4 rounded-2xl border transition-all",
                                    theme === 'dark' ? "bg-white/5 border-white/5" : "bg-white border-slate-100 shadow-sm"
                                  )}>
                                    <span className={cn("text-xs font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{p.name}</span>
                                    <span className="text-[10px] font-black text-blue-500 bg-blue-500/10 px-2 py-1 rounded-lg">x{p.quantity}</span>
                                  </div>
                                ))}
                                {JSON.parse(tx.products_json || '[]').length === 0 && (
                                  <p className="text-xs text-zinc-600 italic">{t('no_products_added')}</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SeparateReports;
