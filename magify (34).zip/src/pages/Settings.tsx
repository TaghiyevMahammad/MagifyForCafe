import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Save, Globe, DollarSign, Shield, Info, Plus, Trash2, Edit2, KeyRound, Sun, Moon } from 'lucide-react';
import { Settings as SettingsType, Device } from '../types';
import { toast } from 'sonner';
import { apiFetch } from '../lib/api';
import { useTheme } from '../contexts/ThemeContext';
import { cn } from '../lib/utils';
import ChangeReportPasswordModal from '../components/ChangeReportPasswordModal';

const Settings: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { theme, setTheme } = useTheme();
  const [isReportPasswordModalOpen, setIsReportPasswordModalOpen] = useState(false);
  const [settings, setSettings] = useState<SettingsType>({
    language: 'az'
  });
  const [devices, setDevices] = useState<Device[]>([]);
  const [isAddingDevice, setIsAddingDevice] = useState(false);
  const [editingDevice, setEditingDevice] = useState<Device | null>(null);
  const [newDevice, setNewDevice] = useState({ name: '', hourly_price: 0, separate_report: false });

  useEffect(() => {
    fetchSettings();
    fetchDevices();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await apiFetch('/api/settings');
      const data = await res.json();
      setSettings(data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  const fetchDevices = async () => {
    try {
      const res = await apiFetch('/api/devices');
      const data = await res.json();
      setDevices(data);
    } catch (error) {
      console.error('Error fetching devices:', error);
    }
  };

  const handleSaveSettings = async () => {
    try {
      const res = await apiFetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings })
      });
      if (res.ok) {
        toast.success(t('success_update'));
        i18n.changeLanguage(settings.language);
      }
    } catch (error) {
      toast.error(t('error_update'));
    }
  };

  const handleAddDevice = async () => {
    if (!newDevice.name) return;
    try {
      const res = await apiFetch('/api/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newDevice)
      });
      if (res.ok) {
        toast.success(t('success_add'));
        setIsAddingDevice(false);
        setNewDevice({ name: '', hourly_price: 0, separate_report: false });
        fetchDevices();
      }
    } catch (error) {
      toast.error(t('error_add'));
    }
  };

  const handleUpdateDevice = async () => {
    if (!editingDevice) return;
    try {
      const res = await apiFetch(`/api/devices/${editingDevice.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingDevice)
      });
      if (res.ok) {
        toast.success(t('success_update'));
        setEditingDevice(null);
        fetchDevices();
      }
    } catch (error) {
      toast.error(t('error_update'));
    }
  };

  const handleDeleteDevice = async (id: number) => {
    if (!confirm(t('confirm_delete'))) return;
    try {
      const res = await apiFetch(`/api/devices/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        toast.success(t('success_delete'));
        fetchDevices();
      }
    } catch (error) {
      toast.error(t('error_delete'));
    }
  };

  return (
    <div className="space-y-6">
      <ChangeReportPasswordModal 
        isOpen={isReportPasswordModalOpen}
        onClose={() => setIsReportPasswordModalOpen(false)}
      />
      <header className="flex justify-between items-end">
        <div>
          <h1 className={cn("text-2xl sm:text-3xl font-bold tracking-tight", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('settings')}</h1>
          <p className="text-zinc-500 text-sm mt-1">{t('manage_settings_desc')}</p>
        </div>
        <button 
          onClick={handleSaveSettings}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl font-bold transition-colors duration-150"
        >
          <Save className="w-4 h-4" />
          {t('save')}
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <section className={cn("border rounded-2xl p-6 space-y-6", theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200")}>
            <div className="flex items-center gap-3">
              <Sun className="w-5 h-5 text-amber-500" />
              <h2 className={cn("text-lg font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('theme')}</h2>
            </div>
            
            <div className="flex gap-4">
              <button
                onClick={() => setTheme('light')}
                className={cn(
                  "flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-colors duration-150 border",
                  theme === 'light' 
                    ? 'bg-blue-600 text-white border-blue-600' 
                    : (theme === 'dark' ? 'bg-white/5 text-zinc-400 border-transparent hover:text-white' : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100')
                )}
              >
                <Sun className="w-4 h-4" />
                {t('light')}
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={cn(
                  "flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-colors duration-150 border",
                  theme === 'dark' 
                    ? 'bg-blue-600 text-white border-blue-600' 
                    : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                )}
              >
                <Moon className="w-4 h-4" />
                {t('dark')}
              </button>
            </div>
          </section>

          <section className={cn("border rounded-2xl p-6 space-y-6", theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200")}>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <DollarSign className="w-5 h-5 text-blue-500" />
                <h2 className={cn("text-lg font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('pricing_config')}</h2>
              </div>
              <button 
                onClick={() => setIsAddingDevice(true)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors duration-150",
                  theme === 'dark' ? "bg-white/5 hover:bg-white/10 text-white" : "bg-slate-50 hover:bg-slate-100 text-slate-900 border border-slate-200"
                )}
              >
                <Plus className="w-4 h-4" />
                {t('add_device')}
              </button>
            </div>
            
            <div className="space-y-3">
              {devices.map(device => (
                <div key={device.id} className={cn(
                  "flex items-center justify-between p-4 rounded-xl border group transition-colors duration-150",
                  theme === 'dark' ? "bg-white/5 border-white/5" : "bg-slate-50/50 border-slate-100 hover:border-slate-200"
                )}>
                  {editingDevice?.id === device.id ? (
                      <div className="flex-1 space-y-4">
                        <div className="flex gap-4 items-center">
                          <input 
                            className={cn(
                              "border rounded-lg px-3 py-1.5 text-sm flex-1 focus:outline-none focus:border-blue-500",
                              theme === 'dark' ? "bg-zinc-800 border-white/10 text-white" : "bg-white border-slate-200 text-slate-900"
                            )}
                            value={editingDevice.name}
                            onChange={e => setEditingDevice({...editingDevice, name: e.target.value})}
                          />
                          <div className="relative w-32">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">₼</span>
                            <input 
                              type="number"
                              className={cn(
                                "w-full border rounded-lg pl-7 pr-3 py-1.5 text-sm focus:outline-none focus:border-blue-500",
                                theme === 'dark' ? "bg-zinc-800 border-white/10 text-white" : "bg-white border-slate-200 text-slate-900"
                              )}
                              value={isNaN(editingDevice.hourly_price) ? '' : editingDevice.hourly_price}
                              onChange={e => setEditingDevice({...editingDevice, hourly_price: parseFloat(e.target.value)})}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <label className="flex items-center gap-2 cursor-pointer group">
                            <div 
                              onClick={() => setEditingDevice({...editingDevice, separate_report: !editingDevice.separate_report})}
                              className={cn(
                                "w-10 h-5 rounded-full transition-colors duration-150 relative",
                                editingDevice.separate_report ? "bg-blue-600" : "bg-zinc-700"
                              )}
                            >
                              <div className={cn(
                                "absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-150",
                                editingDevice.separate_report ? "left-6" : "left-1"
                              )} />
                            </div>
                            <span className="text-xs font-bold text-zinc-500 group-hover:text-zinc-400 uppercase tracking-widest">{t('separate_report')}</span>
                          </label>
                        </div>
                        <div className="flex gap-3 justify-end">
                          <button onClick={handleUpdateDevice} className="text-blue-500 hover:text-blue-400 font-bold text-xs uppercase tracking-widest">{t('save')}</button>
                          <button onClick={() => setEditingDevice(null)} className="text-zinc-500 hover:text-zinc-400 font-bold text-xs uppercase tracking-widest">{t('cancel')}</button>
                        </div>
                      </div>
                  ) : (
                    <>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "font-bold",
                            theme === 'dark' ? "text-white" : "text-slate-900"
                          )}>{device.name}</span>
                          {device.separate_report && (
                            <span className="px-2 py-0.5 bg-blue-600/10 text-blue-500 rounded-md text-[8px] font-black uppercase tracking-widest border border-blue-600/20">
                              {t('separate_report')}
                            </span>
                          )}
                        </div>
                        <span className="text-zinc-500 text-xs font-medium mt-0.5">{t('hourly_rate')}: ₼{device.hourly_price.toFixed(2)}</span>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
                        <button onClick={() => setEditingDevice(device)} className={cn(
                          "p-2 rounded-lg transition-colors",
                          theme === 'dark' ? "hover:bg-white/5 text-zinc-400 hover:text-blue-500" : "hover:bg-blue-50 text-slate-400 hover:text-blue-600"
                        )}>
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDeleteDevice(device.id)} className={cn(
                          "p-2 rounded-lg transition-colors",
                          theme === 'dark' ? "hover:bg-white/5 text-zinc-400 hover:text-red-500" : "hover:bg-rose-50 text-slate-400 hover:text-rose-600"
                        )}>
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}

              {isAddingDevice && (
                <div className={cn(
                  "p-4 rounded-xl border animate-fade-in",
                  theme === 'dark' ? "bg-blue-600/5 border-blue-600/20" : "bg-blue-50/50 border-blue-100"
                )}>
                  <div className="space-y-4">
                    <div className="flex gap-4 items-center">
                      <input 
                        autoFocus
                        placeholder={t('device_name')}
                        className={cn(
                          "border rounded-lg px-3 py-1.5 text-sm flex-1 focus:outline-none focus:border-blue-500",
                          theme === 'dark' ? "bg-zinc-800 border-blue-600/30 text-white" : "bg-white border-blue-200 text-slate-900"
                        )}
                        value={newDevice.name}
                        onChange={e => setNewDevice({...newDevice, name: e.target.value})}
                      />
                      <div className="relative w-32">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">₼</span>
                        <input 
                          type="number"
                          placeholder="0.00"
                          className={cn(
                            "w-full border rounded-lg pl-7 pr-3 py-1.5 text-sm focus:outline-none focus:border-blue-500",
                            theme === 'dark' ? "bg-zinc-800 border-blue-600/30 text-white" : "bg-white border-blue-200 text-slate-900"
                          )}
                          value={isNaN(newDevice.hourly_price) ? '' : newDevice.hourly_price}
                          onChange={e => setNewDevice({...newDevice, hourly_price: parseFloat(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-2 cursor-pointer group">
                        <div 
                          onClick={() => setNewDevice({...newDevice, separate_report: !newDevice.separate_report})}
                          className={cn(
                            "w-10 h-5 rounded-full transition-colors duration-150 relative",
                            newDevice.separate_report ? "bg-blue-600" : "bg-zinc-700"
                          )}
                        >
                          <div className={cn(
                            "absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-150",
                            newDevice.separate_report ? "left-6" : "left-1"
                          )} />
                        </div>
                        <span className="text-xs font-bold text-zinc-500 group-hover:text-zinc-400 uppercase tracking-widest">{t('separate_report')}</span>
                      </label>
                    </div>
                    <div className="flex gap-3 justify-end">
                      <button onClick={handleAddDevice} className="bg-blue-600 text-white px-5 py-2 rounded-lg font-bold text-xs uppercase tracking-widest transition-colors duration-150">{t('add')}</button>
                      <button onClick={() => setIsAddingDevice(false)} className="text-zinc-500 hover:text-zinc-400 font-bold text-xs uppercase tracking-widest">{t('cancel')}</button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>

          <section className={cn("border rounded-2xl p-6 space-y-6", theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200")}>
            <div className="flex items-center gap-3">
              <KeyRound className="w-5 h-5 text-emerald-500" />
              <h2 className={cn("text-lg font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>Hesabat Şifrəsini Dəyiş</h2>
            </div>
            <button
              onClick={() => setIsReportPasswordModalOpen(true)}
              className={cn(
                "flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-colors duration-150 uppercase tracking-widest text-xs border",
                theme === 'dark' ? "bg-emerald-600/10 text-emerald-500 border-emerald-500/20 hover:bg-emerald-600/20" : "bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100"
              )}
            >
              <KeyRound className="w-4 h-4" />
              {t('change_password')}
            </button>
          </section>

          <section className={cn("border rounded-2xl p-6 space-y-6", theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200")}>
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-blue-500" />
              <h2 className={cn("text-lg font-bold", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('language')}</h2>
            </div>
            
            <div className="flex gap-4">
              {['az', 'en', 'ru'].map((lang) => (
                <button
                  key={lang}
                  onClick={() => setSettings({...settings, language: lang})}
                  className={cn(
                    "px-6 py-2.5 rounded-xl font-bold transition-colors duration-150 border",
                    settings.language === lang 
                      ? 'bg-blue-600 text-white border-blue-600' 
                      : (theme === 'dark' ? 'bg-white/5 text-zinc-400 border-transparent hover:text-white' : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100')
                  )}
                >
                  {lang === 'az' ? 'Azərbaycan' : lang === 'en' ? 'English' : 'Русский'}
                </button>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <div className={cn(
            "border rounded-2xl p-6 space-y-4",
            theme === 'dark' ? "bg-blue-600/10 border-blue-600/20" : "bg-blue-50/50 border-blue-200"
          )}>
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-blue-500" />
              <h3 className={cn("font-bold text-sm", theme === 'dark' ? "text-white" : "text-blue-900")}>{t('license_info')}</h3>
            </div>
            <p className={cn("text-xs leading-relaxed", theme === 'dark' ? "text-zinc-400" : "text-slate-600")}>
              {t('license_desc')}
            </p>
            <div className="pt-2">
              <span className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold uppercase rounded-full">{t('active')}</span>
            </div>
          </div>

          <div className={cn(
            "border rounded-2xl p-6 space-y-4",
            theme === 'dark' ? "bg-[#141414] border-white/5" : "bg-white border-slate-200"
          )}>
            <div className="flex items-center gap-3">
              <Info className="w-5 h-5 text-zinc-500" />
              <h3 className={cn("font-bold text-sm", theme === 'dark' ? "text-white" : "text-slate-900")}>{t('about')}</h3>
            </div>
            <p className="text-[11px] text-zinc-500 leading-relaxed">
              Magify {t('version')} 1.0.0<br />
              {t('magify_desc')}<br />
              © 2026 {t('developer')}: Professional Management Systems.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
