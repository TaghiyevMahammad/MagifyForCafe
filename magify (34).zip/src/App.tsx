import { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { useTranslation } from 'react-i18next';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Tables from './pages/Tables';
import Products from './pages/Products';
import Inventory from './pages/Inventory';
import Reports from './pages/Reports';
import Reservations from './pages/Reservations';
import Settings from './pages/Settings';
import InventoryProfit from './pages/InventoryProfit';
import SeparateReports from './pages/SeparateReports';
import DailyNotes from './pages/DailyNotes';
import LoginPage from './pages/LoginPage';
import SplashScreen from './components/SplashScreen';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { SessionProvider } from './contexts/SessionContext';
import { FinancialVisibilityProvider } from './contexts/FinancialVisibilityContext';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { apiFetch } from './lib/api';
import { cn } from './lib/utils';
import './i18n';

const AppRoutes = () => {
  const { i18n, t } = useTranslation();
  const { isAuthenticated, isAdminMode, isLoading } = useAuth();
  const { theme } = useTheme();
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const res = await apiFetch('/api/settings');
        const data = await res.json();
        if (data.language) {
          i18n.changeLanguage(data.language);
        }
      } catch (error) {
        console.error("Failed to load settings:", error);
      }
    };
    loadSettings();
  }, [i18n]);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  if (isLoading) {
    return (
      <div className={cn(
        "min-h-screen flex flex-col items-center justify-center gap-6 transition-colors duration-200",
        theme === 'dark' ? "bg-[#0a0a0a]" : "bg-slate-50"
      )}>
        <img 
          src={theme === 'dark' ? "/logo.png" : "/logo1.png"} 
          alt="Magify Logo" 
          className="w-16 h-auto object-contain animate-pulse"
          referrerPolicy="no-referrer"
        />
        <div className="w-10 h-10 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className={cn(
      "min-h-screen transition-colors duration-200",
      theme === 'dark' ? "bg-black text-white" : "bg-slate-50 text-slate-900"
    )}>
      <Toaster position="top-right" theme={theme === 'dark' ? 'dark' : 'light'} />
      <Routes>
        <Route 
          path="/login" 
          element={!isAuthenticated ? <LoginPage /> : <Navigate to="/tables" replace />} 
        />
        
        <Route 
          path="/" 
          element={isAuthenticated ? <Layout /> : <Navigate to="/login" replace />}
        >
          <Route index element={<Navigate to="/tables" replace />} />
          <Route path="tables" element={<Tables />} />
          <Route 
            path="dashboard" 
            element={isAdminMode ? <Dashboard /> : <Navigate to="/tables" replace />} 
          />
          <Route path="products" element={<Products />} />
          <Route path="inventory" element={<Inventory />} />
          <Route 
            path="inventory-profit" 
            element={isAdminMode ? <InventoryProfit /> : <Navigate to="/tables" replace />} 
          />
          <Route 
            path="reports" 
            element={isAdminMode ? <Reports /> : <Navigate to="/tables" replace />} 
          />
          <Route path="separate-reports" element={<SeparateReports />} />
          <Route path="daily-notes" element={<DailyNotes />} />
          <Route path="reservations" element={<Reservations />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/tables" replace />} />
        </Route>
      </Routes>
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <FinancialVisibilityProvider>
            <SessionProvider>
              <AppRoutes />
            </SessionProvider>
          </FinancialVisibilityProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
