import React, { useState, useEffect, useMemo } from 'react';
import { Gamepad2, Clock, Timer, CheckCircle2, AlertCircle, Edit2, Trash2, StopCircle, Pause, Play } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import { Table, ActiveSession } from '../types';
import { cn, formatCurrency } from '../lib/utils';
import { useSessions } from '../contexts/SessionContext';

interface TableCardProps {
  table: Table;
  size?: 'small' | 'medium' | 'large';
  session?: ActiveSession;
  isSelected?: boolean;
  onClick: (e?: any) => void;
  onEdit: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
  onPause?: (e: React.MouseEvent) => void;
  onResume?: (e: React.MouseEvent) => void;
  onSelectToggle?: (e: React.MouseEvent) => void;
}

const TableCard: React.FC<TableCardProps> = React.memo(({ 
  table, 
  size = 'medium', 
  session, 
  isSelected = false,
  onClick, 
  onEdit, 
  onDelete, 
  onPause, 
  onResume,
  onSelectToggle
}) => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { tick } = useSessions();

  const timerData = useMemo(() => {
    if (!session) return { timeLeft: '', isFinished: false };

    const now = Date.now();
    const totalPausedMs = (session.totalPausedMinutes || 0) * 60000;
    let elapsedMs = now - session.startTime - totalPausedMs;

    if (session.isPaused && session.pausedAt) {
      const currentPauseMs = now - session.pausedAt;
      elapsedMs -= currentPauseMs;
    }

    const elapsed = Math.floor(elapsedMs / 60000);

    if ((session.type === 'fixed' || session.type === 'amount') && session.durationMinutes) {
      const remaining = session.durationMinutes - elapsed;
      if (remaining <= 0) {
        return { timeLeft: '00:00', isFinished: true };
      } else {
        const h = Math.floor(remaining / 60);
        const m = remaining % 60;
        return { 
          timeLeft: `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`,
          isFinished: false 
        };
      }
    } else if (session.type === 'open') {
      const totalElapsed = elapsed + (session.prepaidMinutes || 0);
      const h = Math.floor(totalElapsed / 60);
      const m = totalElapsed % 60;
      return { 
        timeLeft: `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`,
        isFinished: false 
      };
    } else {
      const h = Math.floor(elapsed / 60);
      const m = elapsed % 60;
      return { 
        timeLeft: `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`,
        isFinished: false 
      };
    }
  }, [session, tick]);

  const { timeLeft, isFinished } = timerData;

  const isKabinet = table.type === 'kabinet';
  const isActive = !!session;
  const isPaused = session?.isPaused;

  return (
    <div className="relative group">
      <div
        onClick={onClick}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onClick();
          }
        }}
        className={cn(
          "w-full relative overflow-hidden rounded-2xl border transition-all duration-200 text-left cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
          size === 'small' ? "p-3 sm:p-3.5" : size === 'large' ? "p-6 sm:p-8" : "p-5 sm:p-6",
          isSelected && "ring-2 ring-blue-500 shadow-lg shadow-blue-500/20 scale-[1.01]",
          isActive 
            ? isFinished 
              ? "bg-rose-600/10 border-rose-500/50"
              : isPaused
                ? "bg-amber-600/10 border-amber-500/50"
                : session.type === 'fixed'
                  ? "bg-purple-600/10 border-purple-500/50"
                  : session.type === 'amount'
                    ? "bg-emerald-600/10 border-emerald-500/50"
                    : "bg-blue-600/10 border-blue-500/50"
            : theme === 'dark' 
              ? "bg-[#141414] border-white/5 hover:border-white/10 hover:bg-[#1a1a1a]"
              : "bg-white border-slate-200 hover:border-slate-300"
        )}
      >
        <div className={cn("flex justify-between items-start", size === 'small' ? "mb-2" : "mb-4")}>
          <div className="flex items-center gap-2">
            <div className={cn(
              "rounded-lg",
              size === 'small' ? "p-1.5 sm:p-2" : size === 'large' ? "p-3 sm:p-4" : "p-2.5 sm:p-3",
              isActive 
                ? isFinished 
                  ? "bg-rose-500/20" 
                  : isPaused 
                    ? "bg-amber-500/20" 
                    : session.type === 'fixed'
                      ? "bg-purple-500/20"
                      : session.type === 'amount'
                        ? "bg-emerald-500/20"
                        : "bg-blue-500/20"
                : theme === 'dark' ? "bg-white/5" : "bg-slate-100"
            )}>
              <Gamepad2 className={cn(
                size === 'small' ? "w-4 h-4" : size === 'large' ? "w-6 h-6 sm:w-8 h-8" : "w-5 h-5 sm:w-6 h-6",
                isActive 
                  ? isFinished 
                    ? "text-rose-500" 
                    : isPaused 
                      ? "text-amber-500" 
                      : session.type === 'fixed'
                        ? "text-purple-500"
                        : session.type === 'amount'
                          ? "text-emerald-500"
                          : "text-blue-500"
                  : theme === 'dark' ? "text-zinc-500" : "text-slate-400"
              )} />
            </div>

            {session?.isAlreadyPaid && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500 text-white shadow-sm shadow-emerald-500/30">
                <CheckCircle2 className="w-2.5 h-2.5" />
                {t('already_paid')}
              </span>
            )}
          </div>

          {isActive && (
            <div className={cn(
              "flex items-center gap-1.5 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider shrink-0",
              size === 'small' ? "text-[8px]" : "text-[10px]",
              isFinished 
                ? "bg-rose-500 text-white" 
                : isPaused 
                  ? "bg-amber-500 text-white" 
                  : session.type === 'fixed'
                    ? "bg-purple-500 text-white"
                    : session.type === 'amount'
                      ? "bg-emerald-500 text-white"
                      : "bg-blue-500 text-white"
            )}>
              {isFinished ? <AlertCircle className="w-3 h-3" /> : isPaused ? <Pause className="w-3 h-3" /> : <Timer className="w-3 h-3" />}
              {size !== 'small' && (isFinished ? t('finished') : isPaused ? t('paused') : session.psType)}
              {size === 'small' && session.psType}
            </div>
          )}
        </div>

        <div className="space-y-0.5 overflow-hidden">
          <h3 className={cn(
            "font-bold truncate", 
            size === 'small' ? "text-xs sm:text-sm" : size === 'large' ? "text-lg sm:text-xl" : "text-base sm:text-lg",
            theme === 'dark' ? "text-white" : "text-slate-900"
          )}>{table.name}</h3>
          {size !== 'small' && (
            <p className={cn(
              "text-[10px] sm:text-xs",
              theme === 'dark' ? "text-zinc-500" : "text-slate-500"
            )}>
              {isKabinet ? t('vip_kabinet') : t('standard')}
            </p>
          )}
        </div>

        {isActive ? (
          <div className={cn("flex items-end justify-between", size === 'small' ? "mt-3" : "mt-5 sm:mt-6")}>
            <div className="space-y-0.5">
              {size !== 'small' && (
                <p className={cn(
                  "text-[10px] uppercase tracking-widest font-bold",
                  theme === 'dark' ? "text-zinc-500" : "text-slate-500"
                )}>
                  {session.type === 'open' && !session.setId ? t('elapsed_time') : t('remaining_time')}
                </p>
              )}
              <div className="flex items-center gap-2">
                <p className={cn(
                  "font-mono font-bold tracking-tighter",
                  size === 'small' ? "text-base sm:text-lg" : size === 'large' ? "text-2xl sm:text-4xl" : "text-xl sm:text-2xl",
                  isFinished ? "text-rose-500" : isPaused ? "text-amber-500" : theme === 'dark' ? "text-white" : "text-slate-900"
                )}>
                  {timeLeft}
                </p>
                <div className="flex items-center gap-1">
                  {isPaused ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onResume?.(e);
                      }}
                      className={cn(
                        "bg-amber-500/10 hover:bg-amber-500 text-amber-500 hover:text-white rounded-lg transition-all border border-amber-500/20",
                        size === 'small' ? "p-1" : "p-1.5"
                      )}
                      title={t('resume')}
                    >
                      <Play className={cn("fill-current", size === 'small' ? "w-3 h-3" : "w-4 h-4 sm:w-5 sm:h-5")} />
                    </button>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPause?.(e);
                      }}
                      className={cn(
                        "bg-blue-500/10 hover:bg-blue-500 text-blue-500 hover:text-white rounded-lg transition-all border border-blue-500/20",
                        size === 'small' ? "p-1" : "p-1.5"
                      )}
                      title={t('pause')}
                    >
                      <Pause className={cn("fill-current", size === 'small' ? "w-3 h-3" : "w-4 h-4 sm:w-5 sm:h-5")} />
                    </button>
                  )}
                </div>
              </div>
            </div>
            <div className="text-right">
               {size !== 'small' && (
                 <p className={cn(
                   "text-[10px] uppercase tracking-widest font-bold",
                   theme === 'dark' ? "text-zinc-500" : "text-slate-500"
                 )}>{t('status')}</p>
               )}
               <p className={cn(
                 "font-bold",
                 size === 'small' ? "text-[8px] sm:text-[9px]" : "text-[10px] sm:text-xs",
                 isFinished 
                  ? "text-rose-500" 
                  : isPaused 
                    ? "text-amber-500" 
                    : session.type === 'fixed'
                      ? "text-purple-500"
                      : session.type === 'amount'
                        ? "text-emerald-500"
                        : "text-blue-500"
               )}>
                 {session.type === 'fixed' ? t('fixed_time') : session.type === 'amount' ? t('time_by_amount') : t('open_session')}
                 {size !== 'small' && session.billingMode && (
                   <span className="ml-1 opacity-60">
                     ({t(session.billingMode)})
                   </span>
                 )}
               </p>
               {size !== 'small' && session.billingMode === 'depozit' && session.depositAmount && (
                 <p className={cn(
                   "text-[9px] font-bold mt-0.5",
                   theme === 'dark' ? "text-zinc-500" : "text-slate-500"
                 )}>
                   {t('depozit')}: {formatCurrency(session.depositAmount)}
                 </p>
               )}
            </div>
          </div>
        ) : (
          <div className={cn("flex items-center gap-2 text-emerald-500", size === 'small' ? "mt-3" : "mt-5 sm:mt-6")}>
            <CheckCircle2 className={cn(size === 'small' ? "w-3.5 h-3.5" : "w-3.5 h-3.5 sm:w-4 sm:h-4")} />
            <span className={cn("font-bold uppercase tracking-wider", size === 'small' ? "text-[8px] sm:text-[9px]" : "text-[10px] sm:text-xs")}>{t('available')}</span>
          </div>
        )}
      </div>
      
        <div className="absolute top-2.5 right-2.5 sm:top-4 sm:right-4 flex gap-1 sm:gap-2 opacity-0 group-hover:opacity-100 z-10 transition-opacity">
        {!isActive && (
          <>
            <button 
              onClick={onEdit}
              className="p-1.5 sm:p-2 bg-white/5 hover:bg-white/10 rounded-lg text-zinc-500 hover:text-white border border-white/5"
            >
              <Edit2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
            <button 
              onClick={onDelete}
              className="p-1.5 sm:p-2 bg-white/5 hover:bg-rose-500/20 rounded-lg text-zinc-500 hover:text-rose-500 border border-white/5"
            >
              <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </>
        )}
      </div>
    </div>
  );
});

export default TableCard;
