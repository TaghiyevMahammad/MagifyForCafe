import React, { useState, useEffect } from 'react';
import { 
  X, 
  Play, 
  StopCircle, 
  Plus, 
  Minus, 
  ShoppingCart, 
  Clock, 
  Gamepad2,
  Trash2,
  Receipt,
  Timer,
  Layers,
  ShoppingBag,
  Pause,
  DollarSign,
  CheckCircle2,
  ArrowLeftRight,
  AlertCircle
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../contexts/ThemeContext';
import { Table, ActiveSession, Product, SessionProduct, Settings, InventoryItem, ProductSet, Device } from '../types';
import { useSessions } from '../contexts/SessionContext';
import { formatCurrency, cn, formatDateTime } from '../lib/utils';
import { toast } from 'sonner';
import { apiFetch } from '../lib/api';

import PaymentModal from './PaymentModal';
import SessionConversionCard from './SessionConversionCard';

interface SessionModalProps {
  table: Table;
  session?: ActiveSession;
  onClose: () => void;
  onStart: (session: ActiveSession) => void;
  onEnd: (transaction: any) => void;
}

const SessionModal: React.FC<SessionModalProps> = ({ 
  table, 
  session, 
  onClose, 
  onStart, 
  onEnd
}) => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { updateSession, convertToOpen, convertToFixed } = useSessions();
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<number | null>(null);
  const [selectedSetId, setSelectedSetId] = useState<number | null>(null);
  
  const [sessionType, setSessionType] = useState<'fixed' | 'open' | 'amount'>('open');
  const [fixedDuration, setFixedDuration] = useState<number>(60);
  const [amountToTime, setAmountToTime] = useState<number>(5);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [allSets, setAllSets] = useState<ProductSet[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [elapsedMinutes, setElapsedMinutes] = useState(0);
  const [productTab, setProductTab] = useState<'products' | 'sets'>('products');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [billingMode, setBillingMode] = useState<'adi' | 'depozit'>('adi');
  const [depositAmount, setDepositAmount] = useState<number>(20);
  const [isAlreadyPaid, setIsAlreadyPaid] = useState<boolean>(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [pRes, sRes, iRes, setRes, dRes] = await Promise.all([
          apiFetch('/api/products'),
          apiFetch('/api/product_sets'),
          apiFetch('/api/inventory'),
          apiFetch('/api/settings'),
          apiFetch('/api/devices')
        ]);
        const productsData = await pRes.json();
        const setsData = await sRes.json();
        const inventoryData = await iRes.json();
        const settingsData = await setRes.json();
        const devicesData = await dRes.json();

        setAllProducts(productsData);
        setAllSets(setsData);
        setInventory(inventoryData);
        setSettings(settingsData);
        setDevices(devicesData);
        if (devicesData.length > 0 && !selectedDeviceId) {
          setSelectedDeviceId(devicesData[0].id);
        }
        setIsDataLoaded(true);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();

    if (session) {
      const updateElapsed = () => {
        const now = Date.now();
        const totalPausedMs = (session.totalPausedMinutes || 0) * 60000;
        let elapsedMs = now - session.startTime - totalPausedMs;

        if (session.isPaused && session.pausedAt) {
          const currentPauseMs = now - session.pausedAt;
          elapsedMs -= currentPauseMs;
        }

        const elapsed = Math.floor(elapsedMs / 60000);
        setElapsedMinutes(elapsed);
      };

      updateElapsed();
      const interval = setInterval(updateElapsed, 1000);
      return () => clearInterval(interval);
    }
  }, [session]);

  const handleStart = () => {
    if (!selectedDeviceId) {
      toast.error(t('select_device'));
      return;
    }
    const newSession: ActiveSession = {
      tableId: table.id,
      deviceId: selectedDeviceId,
      startTime: Date.now(),
      type: sessionType,
      durationMinutes: sessionType === 'fixed' 
        ? fixedDuration 
        : sessionType === 'amount'
          ? Math.floor((amountToTime / (devices.find(d => d.id === selectedDeviceId)?.hourly_price || 1)) * 60)
          : undefined,
      products: [],
      prepaidMinutes: 0,
      isPaused: false,
      totalPausedMinutes: 0,
      billingMode: table.type === 'kabinet' ? billingMode : undefined,
      depositAmount: (table.type === 'kabinet' && billingMode === 'depozit') ? depositAmount : undefined,
      isAlreadyPaid: isAlreadyPaid
    };
    onStart(newSession);
  };

  const checkStock = (productId: number, isSet: boolean, quantity: number = 1): boolean => {
    if (isSet) {
      const set = allSets.find(s => s.id === productId);
      if (!set) return false;
      for (const item of set.items) {
        const invItem = inventory.find(i => i.id === item.inventory_id);
        if (!invItem || invItem.stock_quantity < item.quantity_required * quantity) {
          toast.error(`${t('insufficient_stock')}: ${item.inventory_name}`);
          return false;
        }
      }
    } else {
      const product = allProducts.find(p => p.id === productId);
      if (product?.inventory_id) {
        const invItem = inventory.find(i => i.id === product.inventory_id);
        if (!invItem || invItem.stock_quantity < quantity) {
          toast.error(t('insufficient_stock'));
          return false;
        }
      }
    }
    return true;
  };

  const addProductToSession = (product: Product) => {
    if (!session) return;
    
    const existing = session.products.find(p => p.id === product.id && !p.is_set);
    const currentQty = existing ? existing.quantity : 0;
    
    if (!checkStock(product.id, false, currentQty + 1)) return;

    let newProducts;
    if (existing) {
      newProducts = session.products.map(p => 
        (p.id === product.id && !p.is_set) ? { ...p, quantity: p.quantity + 1 } : p
      );
    } else {
      newProducts = [...session.products, { ...product, quantity: 1, is_set: false }];
    }
    updateSession({ ...session, products: newProducts });
  };

  const addSetToSession = (set: ProductSet) => {
    if (!session) return;

    const existing = session.products.find(p => p.set_id === set.id && p.is_set);
    const currentQty = existing ? existing.quantity : 0;

    if (!checkStock(set.id, true, currentQty + 1)) return;

    const includedMinutes = set.device_time?.reduce((acc, dt) => acc + (dt.included_hours * 60), 0) || 0;

    let newProducts;
    if (existing) {
      newProducts = session.products.map(p => 
        (p.set_id === set.id && p.is_set) ? { ...p, quantity: p.quantity + 1 } : p
      );
    } else {
      const setAsProduct: SessionProduct = {
        id: -set.id,
        name: set.name,
        price: set.total_price,
        quantity: 1,
        is_set: true,
        set_id: set.id,
        included_minutes: includedMinutes
      };
      newProducts = [...session.products, setAsProduct];
    }
    updateSession({ ...session, products: newProducts });
  };

  const removeProductFromSession = (productId: number, isSet: boolean) => {
    if (!session) return;
    const existing = session.products.find(p => isSet ? p.set_id === productId : (p.id === productId && !p.is_set));
    if (!existing) return;
    
    let newProducts;
    if (existing.quantity > 1) {
      newProducts = session.products.map(p => 
        (isSet ? p.set_id === productId : (p.id === productId && !p.is_set)) ? { ...p, quantity: p.quantity - 1 } : p
      );
    } else {
      newProducts = session.products.filter(p => !(isSet ? p.set_id === productId : (p.id === productId && !p.is_set)));
    }
    updateSession({ ...session, products: newProducts });
  };

  const calculateCosts = () => {
    if (!session || !settings || !devices.length) return { timeCost: 0, productCost: 0, total: 0, duration: 0, includedMinutesRemaining: 0, extraMinutes: 0 };
    
    const now = Date.now();
    const totalPausedMs = (session.totalPausedMinutes || 0) * 60000;
    let elapsedMs = now - session.startTime - totalPausedMs;

    if (session.isPaused && session.pausedAt) {
      const currentPauseMs = now - session.pausedAt;
      elapsedMs -= currentPauseMs;
    }

    const elapsed = Math.floor(elapsedMs / 60000);
    const manualAddedMinutes = session.prepaidMinutes || 0;
    
    // Sum up included minutes from all sets in the session
    const totalIncludedMinutes = session.products.reduce((acc, p) => {
      if (p.is_set && p.included_minutes) {
        return acc + (p.included_minutes * p.quantity);
      }
      return acc;
    }, 0);

    let duration;
    let billableMinutes;

    if (session.type === 'fixed' || session.type === 'amount') {
      duration = session.durationMinutes || 0;
      billableMinutes = Math.max(0, duration - totalIncludedMinutes);
    } else {
      // Open session
      const totalUsage = elapsed + manualAddedMinutes;
      duration = totalUsage;
      billableMinutes = Math.max(0, totalUsage - totalIncludedMinutes);
    }
    
    const device = devices.find(d => d.id === session.deviceId);
    const hourlyPrice = device ? device.hourly_price : 0;
    
    const timeCost = (billableMinutes / 60) * hourlyPrice;
    const productCost = session.products.reduce((acc, p) => acc + (p.price * p.quantity), 0);
    
    let total = timeCost + productCost;
    let finalPayable = total;

    if (session.billingMode === 'depozit' && session.depositAmount) {
      finalPayable = Math.max(total, session.depositAmount);
    }
    
    const includedMinutesRemaining = Math.max(0, totalIncludedMinutes - duration);
    const extraMinutes = Math.max(0, duration - totalIncludedMinutes);

    return {
      timeCost,
      productCost,
      total,
      finalPayable,
      duration,
      includedMinutesRemaining,
      extraMinutes,
      deviceName: device?.name || '—'
    };
  };

  const handlePause = async () => {
    if (!session || session.isPaused) return;
    const updatedSession: ActiveSession = {
      ...session,
      isPaused: true,
      pausedAt: Date.now()
    };
    await updateSession(updatedSession);
    toast.info(t('paused'));
  };

  const handleResume = async () => {
    if (!session || !session.isPaused || !session.pausedAt) return;
    const now = Date.now();
    const pausedMinutes = Math.floor((now - session.pausedAt) / 60000);
    const updatedSession: ActiveSession = {
      ...session,
      isPaused: false,
      pausedAt: undefined,
      totalPausedMinutes: (session.totalPausedMinutes || 0) + pausedMinutes
    };
    await updateSession(updatedSession);
    toast.success(t('resume'));
  };

  const handleAddTime = async (minutes: number) => {
    if (!session) return;
    
    const newExtension = minutes !== 0 ? {
      minutes,
      timestamp: Date.now()
    } : null;

    let updatedSession: ActiveSession;
    if (session.type === 'open') {
      // For open session, adding time increases prepaidMinutes
      // This fulfills the requirement: countdown first, then overtime
      updatedSession = {
        ...session,
        prepaidMinutes: (session.prepaidMinutes || 0) + minutes,
        extensions: newExtension 
          ? [...(session.extensions || []), newExtension]
          : session.extensions
      };
    } else {
      // For fixed session, just add to duration
      updatedSession = {
        ...session,
        durationMinutes: (session.durationMinutes || 0) + minutes,
        extensions: newExtension 
          ? [...(session.extensions || []), newExtension]
          : session.extensions
      };
    }
    await updateSession(updatedSession);
    if (minutes > 0) {
      toast.success(`+${minutes} ${t('minutes')}`);
    } else {
      toast.info(`${minutes} ${t('minutes')}`);
    }
  };

  const handleEnd = () => {
    setIsPaymentModalOpen(true);
  };

  const confirmEnd = (paymentData: any) => {
    const { timeCost, productCost, finalPayable, duration, deviceName } = calculateCosts();
    const transaction = {
      table_id: table.id,
      table_name: table.name,
      ps_type: deviceName,
      device_id: session?.deviceId,
      start_time: new Date(session!.startTime).toISOString(),
      end_time: new Date().toISOString(),
      duration_minutes: duration,
      time_cost: timeCost,
      product_cost: productCost,
      total_cost: finalPayable,
      products_json: JSON.stringify(session?.products),
      extensions_json: JSON.stringify(session?.extensions || []),
      ...paymentData
    };
    onEnd(transaction);
    setIsPaymentModalOpen(false);
  };

  const { timeCost, productCost, total, finalPayable, deviceName, includedMinutesRemaining, extraMinutes } = calculateCosts();

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 animate-fade-in">
      {isPaymentModalOpen && (
        <PaymentModal 
          total={finalPayable}
          usageTotal={total}
          billingMode={session?.billingMode}
          depositAmount={session?.depositAmount}
          onClose={() => setIsPaymentModalOpen(false)}
          onConfirm={confirmEnd}
        />
      )}
      <div className={cn(
        "w-full max-w-4xl rounded-3xl overflow-hidden shadow-xl flex flex-col max-h-[90vh] border transition-colors duration-200",
        theme === 'dark' ? "bg-[#0A0A0A] border-white/10" : "bg-white border-slate-200"
      )}>
        <div className={cn(
          "p-6 border-b flex justify-between items-center",
          theme === 'dark' ? "border-white/5 bg-white/5" : "border-slate-100 bg-slate-50"
        )}>
          <div className="flex items-center gap-4">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
              theme === 'dark' ? "bg-blue-600/20 text-blue-500" : "bg-blue-600/10 text-blue-600"
            )}>
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className={cn(
                "text-xl font-bold tracking-tight",
                theme === 'dark' ? "text-white" : "text-slate-900"
              )}>{table.name}</h2>
              <p className="text-xs font-bold uppercase tracking-widest text-zinc-500">{table.type === 'kabinet' ? t('vip_kabinet') : t('standard')}</p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className={cn(
              "p-2 rounded-full transition-colors",
              theme === 'dark' ? "hover:bg-white/10 text-zinc-400 hover:text-white" : "hover:bg-slate-200 text-slate-400 hover:text-slate-900"
            )}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col lg:flex-row gap-4 sm:gap-6">
          {!session ? (
            <div className="flex-1 space-y-4 sm:space-y-6">
              {table.type === 'kabinet' && (
                <section className="space-y-3">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('select_mode')}</h3>
                  <div className={cn(
                    "flex p-1 rounded-xl border transition-colors",
                    theme === 'dark' ? "bg-white/5 border-white/5" : "bg-slate-100 border-slate-200"
                  )}>
                    <button 
                      onClick={() => setBillingMode('adi')}
                      className={cn(
                        "flex-1 py-3 rounded-xl font-bold text-xs transition-colors duration-150",
                        billingMode === 'adi' 
                          ? (theme === 'dark' ? "bg-white text-black" : "bg-white text-slate-900 shadow-sm") 
                          : "text-zinc-500"
                      )}
                    >
                      {t('adi')}
                    </button>
                    <button 
                      onClick={() => setBillingMode('depozit')}
                      className={cn(
                        "flex-1 py-3 rounded-xl font-bold text-xs transition-colors duration-150",
                        billingMode === 'depozit' 
                          ? (theme === 'dark' ? "bg-white text-black" : "bg-white text-slate-900 shadow-sm") 
                          : "text-zinc-500"
                      )}
                    >
                      {t('depozit')}
                    </button>
                  </div>
                  
                  {billingMode === 'depozit' && (
                    <div className={cn(
                      "p-4 rounded-xl flex items-center justify-between border transition-colors",
                      theme === 'dark' ? "bg-blue-600/10 border-blue-600/20 text-white" : "bg-blue-50 border-blue-100 text-slate-900"
                    )}>
                      <span className="text-sm font-bold">{t('min_payment')}</span>
                      <div className="flex items-center gap-2">
                        <input 
                          type="number" 
                          value={isNaN(depositAmount) ? '' : depositAmount}
                          onChange={(e) => setDepositAmount(Number(e.target.value))}
                          className={cn(
                            "w-20 rounded-lg px-3 py-1.5 text-right font-mono font-bold focus:outline-none focus:border-blue-500 border transition-all",
                            theme === 'dark' 
                              ? "bg-black/40 border-white/10 text-white" 
                              : "bg-white border-slate-200 text-slate-900"
                          )}
                        />
                        <span className="text-zinc-500 font-bold">₼</span>
                      </div>
                    </div>
                  )}
                </section>
              )}

              <section className="space-y-3">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('select_device')}</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {devices.map((device) => (
                    <button
                      key={device.id}
                      onClick={() => setSelectedDeviceId(device.id)}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2",
                        selectedDeviceId === device.id 
                          ? (theme === 'dark' ? "bg-blue-600/10 border-blue-600 text-white" : "bg-blue-50 border-blue-500 text-slate-900 shadow-md") 
                          : (theme === 'dark' ? "bg-white/5 border-transparent text-zinc-400 hover:bg-white/10" : "bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100")
                      )}
                    >
                      <Gamepad2 className={cn("w-6 h-6", selectedDeviceId === device.id ? "text-blue-500" : "text-zinc-500")} />
                      <div className="flex flex-col items-center gap-1">
                        <span className="font-bold text-[10px] text-center leading-tight">{device.name}</span>
                        {device.separate_report ? (
                          <span className="px-1 py-0.5 bg-amber-500/10 text-amber-500 rounded-[4px] text-[7px] font-black uppercase tracking-tighter border border-amber-500/10">
                            {t('separate_report')}
                          </span>
                        ) : null}
                      </div>
                      <span className="text-[10px] text-zinc-500">{formatCurrency(device.hourly_price)}/h</span>
                    </button>
                  ))}
                </div>
              </section>

              <section className="space-y-3">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('session_type')}</h3>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setSessionType('open')}
                    className={cn(
                      "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1.5",
                      sessionType === 'open' 
                        ? (theme === 'dark' ? "bg-blue-600/10 border-blue-600 text-white shadow-lg shadow-blue-500/10" : "bg-blue-50 border-blue-500 text-slate-900 shadow-md") 
                        : (theme === 'dark' ? "bg-white/5 border-transparent text-zinc-400 hover:bg-white/10" : "bg-slate-100 border-transparent text-slate-500 hover:bg-slate-200")
                    )}
                  >
                    <Clock className={cn("w-5 h-5 transition-colors", sessionType === 'open' ? "text-blue-500" : "text-zinc-500")} />
                    <span className="font-bold text-xs">{t('open_session')}</span>
                  </button>
                  <button
                    onClick={() => setSessionType('fixed')}
                    className={cn(
                      "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1.5",
                      sessionType === 'fixed' 
                        ? (theme === 'dark' ? "bg-blue-600/10 border-blue-600 text-white shadow-lg shadow-blue-500/10" : "bg-blue-50 border-blue-500 text-slate-900 shadow-md") 
                        : (theme === 'dark' ? "bg-white/5 border-transparent text-zinc-400 hover:bg-white/10" : "bg-slate-100 border-transparent text-slate-500 hover:bg-slate-200")
                    )}
                  >
                    <Timer className={cn("w-5 h-5 transition-colors", sessionType === 'fixed' ? "text-blue-500" : "text-zinc-500")} />
                    <span className="font-bold text-xs">{t('fixed_time')}</span>
                  </button>
                  <button
                    onClick={() => setSessionType('amount')}
                    className={cn(
                      "p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1.5",
                      sessionType === 'amount' 
                        ? (theme === 'dark' ? "bg-blue-600/10 border-blue-600 text-white shadow-lg shadow-blue-500/10" : "bg-blue-50 border-blue-500 text-slate-900 shadow-md") 
                        : (theme === 'dark' ? "bg-white/5 border-transparent text-zinc-400 hover:bg-white/10" : "bg-slate-100 border-transparent text-slate-500 hover:bg-slate-200")
                    )}
                  >
                    <DollarSign className={cn("w-5 h-5 transition-colors", sessionType === 'amount' ? "text-blue-500" : "text-zinc-500")} />
                    <span className="font-bold text-[10px] leading-tight text-center">{t('time_by_amount')}</span>
                  </button>
                </div>
              </section>

              {sessionType === 'amount' && (
                <section className="space-y-3 animate-in slide-in-from-top-4 duration-300">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('enter_amount')}</h3>
                  <div className="relative group">
                    <span className={cn(
                      "absolute left-4 top-1/2 -translate-y-1/2 font-bold transition-colors",
                      theme === 'dark' ? "text-zinc-500" : "text-slate-400 group-focus-within:text-blue-500"
                    )}>₼</span>
                    <input 
                      type="number"
                      value={isNaN(amountToTime) ? '' : amountToTime}
                      onChange={(e) => setAmountToTime(parseFloat(e.target.value))}
                      className={cn(
                        "w-full rounded-xl py-3 pl-10 pr-4 font-mono font-bold focus:outline-none focus:border-blue-500 transition-all text-sm border",
                        theme === 'dark' 
                          ? "bg-white/5 border-white/10 text-white" 
                          : "bg-slate-50 border-slate-200 text-slate-900 focus:bg-white focus:shadow-sm"
                      )}
                      placeholder="0.00"
                    />
                  </div>
                  <p className="text-[10px] text-zinc-500 italic">
                    ≈ {Math.floor((amountToTime / (devices.find(d => d.id === selectedDeviceId)?.hourly_price || 1)) * 60)} {t('minutes')}
                  </p>
                </section>
              )}

              {sessionType === 'fixed' && (
                <section className="space-y-3 animate-in slide-in-from-top-4 duration-300">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('duration')}</h3>
                  <div className="grid grid-cols-5 gap-2">
                    {[15, 30, 60, 120, 180].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => setFixedDuration(mins)}
                        className={cn(
                          "py-2 rounded-lg border transition-colors duration-150 font-bold text-xs",
                          fixedDuration === mins 
                            ? "bg-blue-600 border-blue-600 text-white shadow-sm" 
                            : theme === 'dark'
                               ? "bg-white/5 border-white/10 text-zinc-400 hover:bg-white/10"
                               : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                        )}
                      >
                        {mins >= 60 ? `${mins/60}${t('hours').charAt(0)}` : `${mins}${t('minutes').charAt(0)}`}
                      </button>
                    ))}
                  </div>
                </section>
              )}

              {/* Already Paid toggle for new session */}
              <section className="space-y-3">
                <div 
                  onClick={() => setIsAlreadyPaid(!isAlreadyPaid)}
                  className={cn(
                    "p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between",
                    isAlreadyPaid
                      ? "bg-emerald-500/10 border-emerald-500 text-emerald-500 shadow-md shadow-emerald-500/10"
                      : (theme === 'dark' ? "bg-white/5 border-white/5 text-zinc-400 hover:bg-white/10" : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100")
                  )}
                >
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className={cn("w-5 h-5", isAlreadyPaid ? "text-emerald-500" : "text-zinc-500")} />
                    <div>
                      <p className="text-xs font-bold">{t('already_paid')}</p>
                      <p className="text-[10px] opacity-75">{t('mark_as_already_paid')}</p>
                    </div>
                  </div>
                  <div className={cn(
                    "w-5 h-5 rounded-lg border flex items-center justify-center transition-colors",
                    isAlreadyPaid ? "bg-emerald-500 border-emerald-500 text-white" : "border-zinc-500"
                  )}>
                    {isAlreadyPaid && <CheckCircle2 className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>
              </section>
            </div>
          ) : (
            <>
              <div className="flex-1 space-y-6">
                <section className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('add_products')}</h3>
                    <div className={cn(
                      "flex p-1 rounded-xl border transition-colors",
                      theme === 'dark' ? "bg-white/5 border-white/5" : "bg-slate-100 border-slate-200"
                    )}>
                      <button 
                        onClick={() => setProductTab('products')}
                        className={cn(
                          "px-3 py-1 rounded-lg text-[10px] font-bold transition-all", 
                          productTab === 'products' 
                            ? (theme === 'dark' ? "bg-white text-black shadow-md" : "bg-white text-slate-900 shadow-sm") 
                            : "text-zinc-500"
                        )}
                      >
                        {t('products')}
                      </button>
                      <button 
                        onClick={() => setProductTab('sets')}
                        className={cn(
                          "px-3 py-1 rounded-lg text-[10px] font-bold transition-all", 
                          productTab === 'sets' 
                            ? (theme === 'dark' ? "bg-white text-black shadow-md" : "bg-white text-slate-900 shadow-sm") 
                            : "text-zinc-500"
                        )}
                      >
                        {t('product_sets')}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {productTab === 'products' ? (
                      allProducts.map(product => {
                        const invItem = inventory.find(i => i.id === product.inventory_id);
                        const isOutOfStock = invItem && invItem.stock_quantity === 0;
                        return (
                          <button
                            key={product.id}
                            disabled={isOutOfStock}
                            onClick={() => addProductToSession(product)}
                            className={cn(
                              "p-3 border rounded-xl transition-all text-left group relative overflow-hidden",
                              theme === 'dark' ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-slate-200 hover:border-blue-500 hover:bg-slate-50 shadow-sm",
                              isOutOfStock && "opacity-50 grayscale cursor-not-allowed"
                            )}
                          >
                            <p className={cn(
                              "text-xs font-bold transition-colors line-clamp-1",
                              theme === 'dark' ? "text-white group-hover:text-blue-400" : "text-slate-900 group-hover:text-blue-600"
                            )}>{product.name}</p>
                            <div className="flex justify-between items-center mt-1">
                              <p className="text-[10px] text-zinc-500">{formatCurrency(product.price)}</p>
                              {invItem && (
                                <span className={cn("text-[9px] font-bold px-1 py-0.5 rounded", invItem.stock_quantity <= 5 ? "text-amber-500 bg-amber-500/10" : "text-emerald-500 bg-emerald-500/10")}>
                                  {invItem.stock_quantity}
                                </span>
                              )}
                            </div>
                            {isOutOfStock && (
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                <span className="text-[10px] font-bold text-white bg-rose-600 px-2 py-1 rounded uppercase tracking-tighter">{t('out_of_stock')}</span>
                              </div>
                            )}
                          </button>
                        );
                      })
                    ) : (
                      allSets.map(set => {
                        const isOutOfStock = set.items.some(item => {
                          const invItem = inventory.find(i => i.id === item.inventory_id);
                          return !invItem || invItem.stock_quantity < item.quantity_required;
                        });
                        return (
                          <button
                            key={set.id}
                            disabled={isOutOfStock}
                            onClick={() => addSetToSession(set)}
                            className={cn(
                              "p-4 border rounded-2xl transition-all text-left group relative overflow-hidden",
                              theme === 'dark' ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-slate-200 hover:border-emerald-500 hover:bg-slate-50 shadow-sm",
                              isOutOfStock && "opacity-50 grayscale cursor-not-allowed"
                            )}
                          >
                            <p className={cn(
                              "text-sm font-bold transition-colors",
                              theme === 'dark' ? "text-white group-hover:text-blue-400" : "text-slate-900 group-hover:text-blue-600"
                            )}>{set.name}</p>
                            <p className="text-xs text-zinc-500 mt-1">{formatCurrency(set.total_price)}</p>
                            <div className="mt-2 flex flex-wrap gap-1">
                              {set.items.map((item, idx) => (
                                <span key={idx} className={cn(
                                  "text-[8px] px-1 rounded text-zinc-500",
                                  theme === 'dark' ? "bg-white/5" : "bg-slate-100"
                                )}>{item.inventory_name}</span>
                              ))}
                            </div>
                            {isOutOfStock && (
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                <span className="text-[10px] font-bold text-white bg-rose-600 px-2 py-1 rounded uppercase tracking-tighter">{t('out_of_stock')}</span>
                              </div>
                            )}
                          </button>
                        );
                      })
                    )}
                  </div>
                </section>

                <section className="space-y-3">
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{t('active_products')}</h3>
                  <div className="space-y-1.5">
                    {session.products.length === 0 ? (
                      <div className={cn(
                        "p-6 border border-dashed rounded-xl text-center text-zinc-500 text-xs transition-colors",
                        theme === 'dark' ? "border-white/10" : "border-slate-200"
                      )}>
                        {t('no_products_added')}
                      </div>
                    ) : (
                      session.products.map(p => (
                        <div key={p.is_set ? `set-${p.set_id}-${p.id}` : `prod-${p.id}`} className={cn(
                          "flex items-center justify-between p-3 rounded-xl transition-colors",
                          theme === 'dark' ? "bg-white/5" : "bg-slate-50"
                        )}>
                          <div className="flex items-center gap-2.5">
                            <div className={cn(
                              "w-7 h-7 rounded-lg flex items-center justify-center transition-colors",
                              theme === 'dark' ? "bg-blue-600/20" : "bg-blue-600/10"
                            )}>
                              {p.is_set ? <Layers className="w-3.5 h-3.5 text-blue-500" /> : <ShoppingCart className="w-3.5 h-3.5 text-blue-500" />}
                            </div>
                            <div>
                              <p className={cn(
                                "text-xs font-bold",
                                theme === 'dark' ? "text-white" : "text-slate-900"
                              )}>{p.name}</p>
                              <p className="text-[10px] text-zinc-500">{formatCurrency(p.price)}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "flex items-center rounded-lg p-0.5",
                              theme === 'dark' ? "bg-black/20" : "bg-slate-200"
                            )}>
                              <button onClick={() => removeProductFromSession(p.is_set ? p.set_id! : p.id, !!p.is_set)} className={cn("p-1 rounded-md transition-colors", theme === 'dark' ? "hover:bg-white/10 text-zinc-400" : "hover:bg-white text-slate-500")}>
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className={cn(
                                "w-6 text-center text-xs font-bold",
                                theme === 'dark' ? "text-white" : "text-slate-900"
                              )}>{p.quantity}</span>
                              <button 
                                onClick={() => p.is_set ? addSetToSession(allSets.find(s => s.id === p.set_id)!) : addProductToSession(p)} 
                                className={cn("p-1 rounded-md transition-colors", theme === 'dark' ? "hover:bg-white/10 text-zinc-400" : "hover:bg-white text-slate-500")}
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <p className={cn(
                              "text-xs font-bold w-16 text-right",
                              theme === 'dark' ? "text-white" : "text-slate-900"
                            )}>
                              {formatCurrency(p.price * p.quantity)}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </section>
              </div>

              <div className="w-full lg:w-72 space-y-4">
                <div className={cn(
                  "border rounded-2xl p-4 space-y-4 transition-colors",
                  theme === 'dark' ? "bg-white/5 border-white/10 shadow-inner" : "bg-white border-slate-200 shadow-sm"
                )}>
                  <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                    <Receipt className="w-3.5 h-3.5 text-blue-500" />
                    {t('bill_summary')}
                  </h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-500">{t('start_time')}</span>
                      <span className={cn(
                        "font-bold",
                        theme === 'dark' ? "text-white" : "text-slate-900"
                      )}>{formatDateTime(session.startTime)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className={cn(
                        "font-medium",
                        theme === 'dark' ? "text-zinc-400" : "text-slate-500"
                      )}>{t('time_cost')} ({deviceName})</span>
                      <span className={cn(
                        "font-bold",
                        theme === 'dark' ? "text-white" : "text-slate-900"
                      )}>{formatCurrency(timeCost)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className={cn(
                        "font-medium",
                        theme === 'dark' ? "text-zinc-400" : "text-slate-500"
                      )}>{t('product_cost')}</span>
                      <span className={cn(
                        "font-bold",
                        theme === 'dark' ? "text-white" : "text-slate-900"
                      )}>{formatCurrency(productCost)}</span>
                    </div>

                    {session.billingMode === 'depozit' && (
                      <div className={cn(
                        "pt-3 border-t space-y-2",
                        theme === 'dark' ? "border-white/10" : "border-slate-200"
                      )}>
                        <div className="flex justify-between text-xs">
                          <span className="text-zinc-400">{t('usage_amount')}</span>
                          <span className={cn(
                            "font-medium",
                            theme === 'dark' ? "text-white" : "text-slate-900"
                          )}>{formatCurrency(total)}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-zinc-400">{t('min_payment')}</span>
                          <span className={cn(
                            "font-medium",
                            theme === 'dark' ? "text-white" : "text-slate-900"
                          )}>{formatCurrency(session.depositAmount || 0)}</span>
                        </div>
                      </div>
                    )}

                    {includedMinutesRemaining > 0 && (
                      <div className={cn(
                        "pt-3 border-t",
                        theme === 'dark' ? "border-white/10" : "border-slate-200"
                      )}>
                        <div className="flex justify-between text-xs">
                          <span className="text-blue-400 font-bold">{t('included_hours_remaining')}</span>
                          <span className="text-blue-400 font-bold">{Math.floor(includedMinutesRemaining / 60)}h {includedMinutesRemaining % 60}m</span>
                        </div>
                      </div>
                    )}

                    {extraMinutes > 0 && (
                      <div className={cn(
                        "pt-3 border-t",
                        theme === 'dark' ? "border-white/10" : "border-slate-200"
                      )}>
                        <div className="flex justify-between text-xs">
                          <span className="text-amber-500 font-bold">{t('extra_charges_active')}</span>
                          <span className="text-amber-500 font-bold">{Math.floor(extraMinutes / 60)}h {extraMinutes % 60}m</span>
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-2">
                      <span className="text-xs text-zinc-400">
                        {session.type === 'open' ? t('current_amount') : t('final_payment')}
                      </span>
                      <span className="text-2xl font-bold text-blue-500 tracking-tighter">
                        {formatCurrency(finalPayable)}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-white/10">
                      <button
                        type="button"
                        onClick={async () => {
                          if (!session) return;
                          const updated = {
                            ...session,
                            isAlreadyPaid: !session.isAlreadyPaid
                          };
                          await updateSession(updated);
                          toast.success(updated.isAlreadyPaid ? t('already_paid') : t('success_update'));
                        }}
                        className={cn(
                          "w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 border transition-all cursor-pointer",
                          session.isAlreadyPaid
                            ? "bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-500/20"
                            : (theme === 'dark' ? "bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10" : "bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200")
                        )}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{session.isAlreadyPaid ? t('already_paid') : t('mark_as_already_paid')}</span>
                      </button>
                    </div>
                  </div>
                </div>

                <SessionConversionCard 
                  session={session} 
                  tableId={table.id} 
                  elapsedMinutes={elapsedMinutes} 
                />

                <div className={cn(
                  "border rounded-2xl p-4 transition-colors",
                  theme === 'dark' ? "bg-blue-600/10 border-blue-600/20" : "bg-blue-50 border-blue-100"
                )}>
                    <div className="flex items-center gap-2 mb-3">
                      <Clock className="w-4 h-4 text-blue-500" />
                      <span className={cn(
                        "text-xs font-bold",
                        theme === 'dark' ? "text-white" : "text-slate-900"
                      )}>{t('session_progress')}</span>
                    </div>
                    <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1">
                      {session.type === 'open' ? t('elapsed_time') : t('remaining_time')}
                    </p>
                    <p className={cn(
                      "text-xl font-mono font-bold tracking-tighter",
                      session.type === 'open' ? (theme === 'dark' ? "text-white" : "text-slate-900") : (session.prepaidMinutes! > 0 && elapsedMinutes >= session.prepaidMinutes!) || (!!session.durationMinutes && elapsedMinutes >= session.durationMinutes) ? "text-rose-500" : (theme === 'dark' ? "text-white" : "text-slate-900")
                    )}>
                      {session.type === 'open' ? (
                        `${elapsedMinutes + (session.prepaidMinutes || 0)} ${t('minutes')}`
                      ) : (
                        session.prepaidMinutes! > 0 
                          ? (elapsedMinutes < session.prepaidMinutes! 
                              ? `${session.prepaidMinutes! - elapsedMinutes} ${t('min_left')}`
                              : `${elapsedMinutes - session.prepaidMinutes!} ${t('extra_time_label')}`
                            )
                          : (session.type === 'fixed' || session.type === 'amount'
                              ? `${Math.max(0, (session.durationMinutes || 0) - elapsedMinutes)} ${t('min_left')}`
                              : `${elapsedMinutes} ${t('min_elapsed')}`
                            )
                      )}
                    </p>
                   {session.prepaidMinutes! > 0 && (
                     <p className="text-[9px] text-blue-400 mt-1 font-bold uppercase tracking-widest">
                       {t('prepaid')}: {session.prepaidMinutes} {t('minutes')}
                     </p>
                   )}

                   <div className={cn(
                     "mt-4 pt-4 border-t space-y-3",
                     theme === 'dark' ? "border-blue-600/20" : "border-blue-200"
                   )}>
                     <div className="space-y-1.5">
                       <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">{t('add_time')}</p>
                       <div className="grid grid-cols-3 gap-1.5">
                         {[15, 30, 60].map((mins) => (
                           <button
                             key={mins}
                             onClick={() => handleAddTime(mins)}
                             className={cn(
                               "py-1.5 rounded-lg transition-all text-[10px] font-bold border",
                               theme === 'dark' ? "bg-blue-600/20 hover:bg-blue-600 text-blue-500 hover:text-white border-blue-600/30" : "bg-blue-600 text-white hover:bg-blue-700 border-blue-600 shadow-sm"
                             )}
                           >
                             +{mins >= 60 ? `1h` : `${mins}m`}
                           </button>
                         ))}
                       </div>
                     </div>
                     <div className="space-y-1.5">
                       <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">{t('remove_time')}</p>
                       <div className="grid grid-cols-3 gap-1.5">
                         {[15, 30, 60].map((mins) => (
                           <button
                             key={mins}
                             onClick={() => handleAddTime(-mins)}
                             className={cn(
                               "py-1.5 rounded-lg transition-all text-[10px] font-bold border",
                               theme === 'dark' ? "bg-rose-600/10 hover:bg-rose-600 text-rose-500 hover:text-white border-rose-600/20" : "bg-rose-50 text-rose-600 hover:bg-rose-100 border-rose-200"
                             )}
                           >
                             -{mins >= 60 ? `1h` : `${mins}m`}
                           </button>
                         ))}
                       </div>
                     </div>
                   </div>
                </div>
              </div>
            </>
          )}
        </div>

        <div className={cn(
          "p-4 border-t flex justify-end gap-3 transition-colors",
          theme === 'dark' ? "border-white/5 bg-white/5" : "border-slate-100 bg-slate-50"
        )}>
          <button
            onClick={onClose}
            className={cn(
              "px-5 py-2 rounded-xl font-bold transition-all text-sm",
              theme === 'dark' ? "text-zinc-400 hover:bg-white/5" : "text-slate-500 hover:bg-slate-200 hover:text-slate-900"
            )}
          >
            {t('cancel')}
          </button>
          {!session ? (
            <button
              onClick={handleStart}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-600/20 flex items-center gap-2 transition-all text-sm"
            >
              <Play className="w-4 h-4 fill-current" />
              {t('start_session')}
            </button>
          ) : (
            <div className="flex gap-2">
              {session.isPaused ? (
                <button
                  onClick={handleResume}
                  className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold shadow-lg shadow-amber-600/20 flex items-center gap-2 transition-all text-sm"
                >
                  <Play className="w-4 h-4 fill-current" />
                  {t('resume')}
                </button>
              ) : (
                <button
                  onClick={handlePause}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-600/20 flex items-center gap-2 transition-all text-sm"
                >
                  <Pause className="w-4 h-4 fill-current" />
                  {t('pause')}
                </button>
              )}
              <button
                onClick={handleEnd}
                className="px-6 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold shadow-lg shadow-rose-600/20 flex items-center gap-2 transition-all text-sm"
              >
                <Receipt className="w-4 h-4" />
                {t('end_bill')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SessionModal;
