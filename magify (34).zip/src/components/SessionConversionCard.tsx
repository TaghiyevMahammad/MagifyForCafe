import React, { useState } from 'react';
import { ArrowLeftRight, Timer, Clock, X, AlertCircle, Sparkles } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { ActiveSession } from '../types';
import { useSessions } from '../contexts/SessionContext';
import { useTheme } from '../contexts/ThemeContext';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

interface SessionConversionCardProps {
  session: ActiveSession;
  tableId: number;
  elapsedMinutes: number;
}

const SessionConversionCard: React.FC<SessionConversionCardProps> = ({
  session,
  tableId,
  elapsedMinutes
}) => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { convertToOpen, convertToFixed } = useSessions();
  const [isConvertingToFixed, setIsConvertingToFixed] = useState(false);
  const [targetFixedDuration, setTargetFixedDuration] = useState<number>(60);

  const handleConvertToOpen = async () => {
    try {
      await convertToOpen(tableId);
      toast.success(t('session_converted_to_open'));
    } catch (error) {
      toast.error(t('error_update'));
    }
  };

  const handleConfirmConvertToFixed = async () => {
    if (targetFixedDuration <= elapsedMinutes) {
      toast.error(t('conversion_duration_too_short', { elapsed: elapsedMinutes }));
      return;
    }
    try {
      await convertToFixed(tableId, targetFixedDuration);
      setIsConvertingToFixed(false);
      toast.success(t('session_converted_to_fixed'));
    } catch (error) {
      toast.error(t('error_update'));
    }
  };

  return (
    <div
      id="session-type-conversion-card"
      className={cn(
        "border rounded-2xl p-4 transition-all duration-200",
        theme === 'dark'
          ? "bg-purple-950/20 border-purple-500/20 text-white"
          : "bg-purple-50/70 border-purple-200 text-slate-900 shadow-sm"
      )}
    >
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <div
            className={cn(
              "p-1.5 rounded-lg",
              theme === 'dark' ? "bg-purple-500/20 text-purple-400" : "bg-purple-600/10 text-purple-600"
            )}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
          </div>
          <div>
            <h4 className="text-xs font-bold">{t('convert_session_type')}</h4>
            <p className="text-[10px] text-zinc-400">
              {session.type === 'open' ? t('open_session') : t('fixed_time')}
            </p>
          </div>
        </div>

        <span
          className={cn(
            "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
            session.type === 'open'
              ? theme === 'dark'
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-emerald-100 text-emerald-800 border border-emerald-300"
              : theme === 'dark'
              ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
              : "bg-blue-100 text-blue-800 border border-blue-300"
          )}
        >
          {session.type === 'open' ? t('open_session') : t('fixed_time')}
        </span>
      </div>

      {session.type !== 'open' ? (
        /* FIXED -> OPEN CONVERSION */
        <div className="space-y-2.5 pt-1">
          <p className="text-[11px] text-zinc-400 leading-snug">
            {t('convert_to_open_desc')}
          </p>

          <div
            className={cn(
              "p-2.5 rounded-xl border text-[11px] flex items-center justify-between",
              theme === 'dark' ? "bg-black/30 border-white/5" : "bg-white border-purple-100"
            )}
          >
            <span className="text-zinc-400">{t('current_elapsed')}:</span>
            <span className="font-bold font-mono text-purple-400">
              {elapsedMinutes} {t('minutes')}
            </span>
          </div>

          <button
            type="button"
            id="btn-convert-to-open"
            onClick={handleConvertToOpen}
            className={cn(
              "w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md",
              "bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/20"
            )}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>{t('convert_to_open')}</span>
          </button>
        </div>
      ) : (
        /* OPEN -> FIXED CONVERSION */
        <div className="space-y-2.5 pt-1">
          {!isConvertingToFixed ? (
            <>
              <p className="text-[11px] text-zinc-400 leading-snug">
                {t('convert_to_fixed_desc')}
              </p>
              <div
                className={cn(
                  "p-2.5 rounded-xl border text-[11px] flex items-center justify-between",
                  theme === 'dark' ? "bg-black/30 border-white/5" : "bg-white border-purple-100"
                )}
              >
                <span className="text-zinc-400">{t('current_elapsed')}:</span>
                <span className="font-bold font-mono text-purple-400">
                  {elapsedMinutes} {t('minutes')}
                </span>
              </div>
              <button
                type="button"
                id="btn-open-convert-to-fixed"
                onClick={() => {
                  const initialTarget = Math.max(30, Math.ceil((elapsedMinutes + 15) / 15) * 15);
                  setTargetFixedDuration(initialTarget);
                  setIsConvertingToFixed(true);
                }}
                className={cn(
                  "w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md",
                  "bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/20"
                )}
              >
                <Timer className="w-3.5 h-3.5" />
                <span>{t('convert_to_fixed')}</span>
              </button>
            </>
          ) : (
            <div
              className={cn(
                "space-y-3 p-3 rounded-xl border animate-in fade-in zoom-in-95 duration-150",
                theme === 'dark' ? "bg-black/40 border-purple-500/20" : "bg-white border-purple-200"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400">
                  {t('select_target_duration')}
                </span>
                <button
                  type="button"
                  onClick={() => setIsConvertingToFixed(false)}
                  className="text-[10px] text-zinc-400 hover:text-white p-0.5 rounded cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Quick "+ from now" additions */}
              <div className="space-y-1">
                <span className="text-[10px] text-zinc-400 font-semibold">{t('presets_from_now')}</span>
                <div className="grid grid-cols-4 gap-1">
                  {[15, 30, 45, 60].map(addMins => {
                    const val = elapsedMinutes + addMins;
                    return (
                      <button
                        key={addMins}
                        type="button"
                        onClick={() => setTargetFixedDuration(val)}
                        className={cn(
                          "py-1 px-1.5 rounded-lg text-[10px] font-bold transition-all border cursor-pointer",
                          targetFixedDuration === val
                            ? "bg-purple-600 text-white border-purple-600 shadow-sm"
                            : theme === 'dark'
                            ? "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-300"
                            : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700"
                        )}
                      >
                        +{addMins}m
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Standard absolute duration presets */}
              <div className="space-y-1">
                <span className="text-[10px] text-zinc-400 font-semibold">{t('duration')}</span>
                <div className="grid grid-cols-4 gap-1">
                  {[30, 45, 60, 90, 120, 180, 240, 300].map(mins => {
                    const isTooShort = mins <= elapsedMinutes;
                    return (
                      <button
                        key={mins}
                        type="button"
                        disabled={isTooShort}
                        onClick={() => setTargetFixedDuration(mins)}
                        className={cn(
                          "py-1 px-1.5 rounded-lg text-[10px] font-bold transition-all border",
                          targetFixedDuration === mins
                            ? "bg-purple-600 text-white border-purple-600 shadow-sm"
                            : isTooShort
                            ? "opacity-35 bg-white/5 border-white/5 text-zinc-600 cursor-not-allowed"
                            : theme === 'dark'
                            ? "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-300 cursor-pointer"
                            : "bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-700 cursor-pointer"
                        )}
                      >
                        {mins >= 60 ? `${mins / 60}h` : `${mins}m`}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Duration Input */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-zinc-400 shrink-0">{t('custom_minutes')}:</span>
                <input
                  type="number"
                  min={elapsedMinutes + 1}
                  value={targetFixedDuration || ''}
                  onChange={(e) => setTargetFixedDuration(parseInt(e.target.value, 10) || 0)}
                  className={cn(
                    "w-full px-2.5 py-1 text-xs rounded-lg border font-mono font-bold outline-none",
                    theme === 'dark' ? "bg-black/50 border-white/15 text-white" : "bg-slate-50 border-slate-300 text-slate-900"
                  )}
                />
              </div>

              {/* Real-time Calculation Summary */}
              <div
                className={cn(
                  "space-y-1 p-2 rounded-lg border text-[11px]",
                  theme === 'dark' ? "bg-black/40 border-white/5" : "bg-slate-50 border-slate-200"
                )}
              >
                <div className="flex justify-between text-zinc-400">
                  <span>{t('current_elapsed')}:</span>
                  <span className="font-mono text-zinc-300">
                    {elapsedMinutes} {t('minutes')}
                  </span>
                </div>
                <div className="flex justify-between font-bold">
                  <span className="text-purple-400">{t('new_remaining_time')}:</span>
                  <span
                    className={cn(
                      "font-mono",
                      targetFixedDuration > elapsedMinutes ? "text-emerald-400" : "text-rose-400"
                    )}
                  >
                    {targetFixedDuration > elapsedMinutes
                      ? `${targetFixedDuration - elapsedMinutes} ${t('minutes')}`
                      : `0 ${t('minutes')}`}
                  </span>
                </div>
              </div>

              {/* Validation Alert */}
              {targetFixedDuration <= elapsedMinutes && (
                <div className="flex items-start gap-1.5 p-2 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px]">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{t('conversion_duration_too_short', { elapsed: elapsedMinutes })}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsConvertingToFixed(false)}
                  className={cn(
                    "flex-1 py-1.5 rounded-lg border text-xs font-bold transition-colors cursor-pointer",
                    theme === 'dark'
                      ? "border-white/10 text-zinc-400 hover:text-white"
                      : "border-slate-200 text-slate-600 hover:bg-slate-100"
                  )}
                >
                  {t('cancel')}
                </button>
                <button
                  type="button"
                  id="btn-confirm-convert-to-fixed"
                  disabled={targetFixedDuration <= elapsedMinutes}
                  onClick={handleConfirmConvertToFixed}
                  className={cn(
                    "flex-1 py-1.5 rounded-lg text-white text-xs font-bold transition-all shadow-md",
                    targetFixedDuration > elapsedMinutes
                      ? "bg-purple-600 hover:bg-purple-500 shadow-purple-600/20 cursor-pointer"
                      : "bg-zinc-700 opacity-50 cursor-not-allowed"
                  )}
                >
                  {t('conversion_confirm')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SessionConversionCard;
