import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { ActiveSession, Table } from '../types';
import { apiFetch } from '../lib/api';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { Bell, Volume2, VolumeX, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SessionContextType {
  sessions: Record<number, ActiveSession>;
  startSession: (session: ActiveSession) => Promise<void>;
  updateSession: (session: ActiveSession) => Promise<void>;
  endSession: (tableId: number) => Promise<void>;
  convertToOpen: (tableId: number) => Promise<void>;
  convertToFixed: (tableId: number, durationMinutes: number) => Promise<void>;
  refreshSessions: () => Promise<void>;
  loading: boolean;
  tick: number;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);

export const SessionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { t } = useTranslation();
  const [sessions, setSessions] = useState<Record<number, ActiveSession>>({});
  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  const alertedSessions = useRef<Set<number>>(new Set());
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [activeAlert, setActiveAlert] = useState<{ tableId: number, tableName: string } | null>(null);

  useEffect(() => {
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audioRef.current.loop = true;
  }, []);

  const stopAlarm = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setActiveAlert(null);
  };

  useEffect(() => {
    const fetchTables = async () => {
      try {
        const res = await apiFetch('/api/tables');
        const data = await res.json();
        setTables(data);
      } catch (e) {
        console.error("Failed to fetch tables in context:", e);
      }
    };
    fetchTables();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTick(t => t + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const checkSessions = () => {
      const now = Date.now();
      Object.values(sessions).forEach((session: ActiveSession) => {
        if ((session.type === 'fixed' || session.type === 'amount') && session.durationMinutes) {
          const totalPausedMs = (session.totalPausedMinutes || 0) * 60000;
          let elapsedMs = now - session.startTime - totalPausedMs;

          if (session.isPaused && session.pausedAt) {
            const currentPauseMs = now - session.pausedAt;
            elapsedMs -= currentPauseMs;
          }

          const elapsedMinutes = Math.floor(elapsedMs / 60000);
          const remaining = session.durationMinutes - elapsedMinutes;

          if (remaining <= 0 && !alertedSessions.current.has(session.tableId)) {
            alertedSessions.current.add(session.tableId);
            
            const table = tables.find(t => t.id === session.tableId);
            const tableName = table ? table.name : `Masa ${session.tableId}`;
            
            // Play sound
            audioRef.current?.play().catch(e => console.error("Audio play failed:", e));
            
            // Show alert modal
            setActiveAlert({ tableId: session.tableId, tableName });
            
            // Also show toast as backup
            toast.error(`${tableName} ${t('session_finished')}`, {
              duration: 10000,
              description: t('time_is_up_desc'),
            });
          }
        }
      });
    };

    // Check alerts every 5 ticks (approx 5 seconds) to save CPU
    if (tick % 5 === 0) {
      checkSessions();
    }
  }, [sessions, t, tables, tick]);

  const refreshSessions = useCallback(async () => {
    try {
      const res = await apiFetch('/api/active_sessions');
      if (res.ok) {
        const data: ActiveSession[] = await res.json();
        const sessionMap: Record<number, ActiveSession> = {};
        data.forEach(s => {
          sessionMap[s.tableId] = s;
        });
        setSessions(sessionMap);
        console.log("Sessions restored from database");
      }
    } catch (error) {
      console.error("Failed to fetch active sessions:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSessions();
  }, [refreshSessions]);

  const startSession = async (session: ActiveSession) => {
    try {
      const res = await apiFetch('/api/active_sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(session)
      });
      if (res.ok) {
        setSessions(prev => ({ ...prev, [session.tableId]: session }));
      }
    } catch (error) {
      console.error("Failed to start session:", error);
      throw error;
    }
  };

  const updateSession = async (session: ActiveSession) => {
    try {
      const res = await apiFetch(`/api/active_sessions/${session.tableId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(session)
      });
      if (res.ok) {
        setSessions(prev => ({ ...prev, [session.tableId]: session }));
      }
    } catch (error) {
      console.error("Failed to update session:", error);
      throw error;
    }
  };

  const endSession = async (tableId: number) => {
    try {
      const res = await apiFetch(`/api/active_sessions/${tableId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setSessions(prev => {
          const newSessions = { ...prev };
          delete newSessions[tableId];
          return newSessions;
        });
        alertedSessions.current.delete(tableId);
      }
    } catch (error) {
      console.error("Failed to end session:", error);
      throw error;
    }
  };

  const convertToOpen = async (tableId: number) => {
    const current = sessions[tableId];
    if (!current) return;
    const updated: ActiveSession = {
      ...current,
      type: 'open',
      durationMinutes: undefined
    };
    alertedSessions.current.delete(tableId);
    if (activeAlert?.tableId === tableId) {
      stopAlarm();
    }
    await updateSession(updated);
  };

  const convertToFixed = async (tableId: number, durationMinutes: number) => {
    const current = sessions[tableId];
    if (!current) return;
    const updated: ActiveSession = {
      ...current,
      type: 'fixed',
      durationMinutes: durationMinutes
    };
    const now = Date.now();
    const totalPausedMs = (current.totalPausedMinutes || 0) * 60000;
    let elapsedMs = now - current.startTime - totalPausedMs;
    if (current.isPaused && current.pausedAt) {
      elapsedMs -= (now - current.pausedAt);
    }
    const elapsedMinutes = Math.floor(elapsedMs / 60000);
    if (durationMinutes > elapsedMinutes) {
      alertedSessions.current.delete(tableId);
      if (activeAlert?.tableId === tableId) {
        stopAlarm();
      }
    }
    await updateSession(updated);
  };

  const contextValue = React.useMemo(() => ({
    sessions,
    startSession,
    updateSession,
    endSession,
    convertToOpen,
    convertToFixed,
    refreshSessions,
    loading,
    tick
  }), [sessions, loading, tick, refreshSessions]);

  return (
    <SessionContext.Provider value={contextValue}>
      {children}
      
      <AnimatePresence>
        {activeAlert && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-[#0f0f0f] border border-rose-500/30 w-full max-w-md rounded-[32px] overflow-hidden shadow-[0_0_50px_-12px_rgba(244,63,94,0.5)]"
            >
              <div className="p-8 text-center space-y-6">
                <div className="mx-auto w-20 h-20 bg-rose-500/10 rounded-full flex items-center justify-center animate-pulse">
                  <Bell className="w-10 h-10 text-rose-500" />
                </div>
                
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold text-white tracking-tight">
                    {activeAlert.tableName} {t('time_is_up')}!
                  </h2>
                  <p className="text-zinc-400 font-medium">
                    {t('time_is_up_desc')}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <button
                    onClick={stopAlarm}
                    className="flex items-center justify-center gap-2 px-6 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-white font-bold transition-all group"
                  >
                    <VolumeX className="w-5 h-5 text-zinc-400 group-hover:text-white transition-colors" />
                    <span>{t('stop_alarm')}</span>
                  </button>
                  <button
                    onClick={stopAlarm}
                    className="flex items-center justify-center gap-2 px-6 py-4 bg-rose-500 hover:bg-rose-600 rounded-2xl text-white font-bold shadow-lg shadow-rose-500/20 transition-all"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                    <span>{t('ok')}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </SessionContext.Provider>
  );
};

export const useSessions = () => {
  const context = useContext(SessionContext);
  if (context === undefined) {
    throw new Error('useSessions must be used within a SessionProvider');
  }
  return context;
};
