export interface Device {
  id: number;
  name: string;
  hourly_price: number;
  separate_report?: boolean | number;
}

export interface Table {
  id: number;
  name: string;
  type: 'kabinet' | 'table';
  hourly_price: number;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  category?: string;
  inventory_id?: number | null; // Link to inventory if it's a physical product
}

export interface InventoryItem {
  id: number;
  name: string;
  stock_quantity: number;
  original_quantity: number;
  purchase_price: number;
  is_stockless?: boolean | number; // Added field
  price?: number;
}

export interface ProductSet {
  id: number;
  name: string;
  total_price: number;
  items: SetItem[];
  device_time?: SetDeviceTime[];
}

export interface SetDeviceTime {
  device_id: number;
  included_hours: number;
  device_name?: string; // For UI
}

export interface SetItem {
  set_id: number;
  inventory_id: number;
  quantity_required: number;
  inventory_name?: string; // For UI
}

export interface SessionExtension {
  minutes: number;
  timestamp: number;
}

export interface Transaction {
  id: number;
  table_id: number;
  table_name: string;
  ps_type: string;
  device_id?: number;
  start_time: string;
  end_time: string;
  duration_minutes: number;
  time_cost: number;
  product_cost: number;
  total_cost: number;
  products_json: string;
  created_at: string;
  cash_amount: number;
  card_amount: number;
  payment_type: 'cash' | 'card' | 'mixed' | 'unpaid';
  extensions_json?: string;
}

export interface SessionProduct extends Product {
  quantity: number;
  is_set?: boolean;
  set_id?: number;
  included_minutes?: number;
}

export interface Reservation {
  id: number;
  customer_name: string;
  customer_phone?: string;
  table_id: number;
  table_name?: string;
  table_type?: 'kabinet' | 'table';
  reservation_time: string;
  duration_minutes: number;
  notes?: string;
  status: 'pending' | 'confirmed' | 'active' | 'cancelled' | 'completed';
  created_at?: string;
}

export interface ActiveSession {
  tableId: number;
  psType?: string; // Optional for compatibility
  deviceId?: number;
  startTime: number;
  type: 'fixed' | 'open' | 'amount';
  durationMinutes?: number;
  prepaidMinutes?: number;
  setId?: number;
  products: SessionProduct[];
  isFinished?: boolean;
  isPaused?: boolean;
  pausedAt?: number;
  totalPausedMinutes?: number;
  billingMode?: 'adi' | 'depozit';
  depositAmount?: number;
  extensions?: SessionExtension[];
  isAlreadyPaid?: boolean;
}

export interface SystemLog {
  id: number;
  event: string;
  details?: string;
  created_at: string;
}

export interface Settings {
  language: string;
  [key: string]: string;
}

export interface DailyNoteRow {
  id: string;
  time: string;
  category: 'general' | 'shift' | 'cash' | 'maintenance' | 'customer' | 'inventory' | 'task';
  title: string;
  note: string;
  amount?: string;
  is_important?: boolean;
  is_done?: boolean;
  created_at?: string;
}

export interface DailyNoteRecord {
  date: string; // YYYY-MM-DD (business day start date)
  general_notes: string;
  rows: DailyNoteRow[];
  updated_at?: string;
}
