import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const getFormattedLogTime = () => {
  const now = new Date();
  const d = String(now.getDate()).padStart(2, '0');
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const y = now.getFullYear();
  const h = String(now.getHours()).padStart(2, '0');
  const mn = String(now.getMinutes()).padStart(2, '0');
  return `${d}/${m}/${y} ${h}:${mn}`;
};

const dbPath = process.env.USER_DATA_PATH 
  ? path.join(process.env.USER_DATA_PATH, "database.db")
  : "database.db";

const db = new Database(dbPath);
db.exec("PRAGMA foreign_keys = ON;");

// Initialize Database
function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS auth_sessions (
      token TEXT PRIMARY KEY,
      machine_id TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      hourly_price REAL DEFAULT 0,
      separate_report INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS set_devices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      set_id INTEGER NOT NULL,
      device_id INTEGER NOT NULL,
      included_hours REAL NOT NULL,
      FOREIGN KEY (set_id) REFERENCES product_sets(id) ON DELETE CASCADE,
      FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS active_sessions (
      table_id INTEGER PRIMARY KEY,
      ps_type TEXT,
      device_id INTEGER,
      start_time INTEGER,
      type TEXT, -- 'fixed' or 'open'
      duration_minutes INTEGER,
      prepaid_minutes INTEGER DEFAULT 0,
      products_json TEXT DEFAULT '[]',
      extensions_json TEXT DEFAULT '[]',
      is_paused INTEGER DEFAULT 0,
      paused_at INTEGER,
      total_paused_minutes INTEGER DEFAULT 0,
      FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS tables (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL, -- 'cabin' or 'table'
      hourly_price REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      category TEXT,
      inventory_id INTEGER,
      FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      stock_quantity INTEGER DEFAULT 0,
      purchase_price REAL DEFAULT 0,
      is_stockless INTEGER DEFAULT 0,
      price REAL DEFAULT 0 -- Kept for compatibility
    );

    CREATE TABLE IF NOT EXISTS product_sets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      total_price REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS set_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      set_id INTEGER NOT NULL,
      inventory_id INTEGER NOT NULL,
      quantity_required INTEGER NOT NULL,
      FOREIGN KEY (set_id) REFERENCES product_sets(id) ON DELETE CASCADE,
      FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      table_id INTEGER,
      table_name TEXT,
      ps_type TEXT,
      device_id INTEGER,
      start_time DATETIME,
      end_time DATETIME,
      duration_minutes INTEGER,
      time_cost REAL,
      product_cost REAL,
      total_cost REAL,
      cash_amount REAL DEFAULT 0,
      card_amount REAL DEFAULT 0,
      payment_type TEXT DEFAULT 'cash',
      products_json TEXT,
      extensions_json TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS system_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS reservations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT,
      table_id INTEGER NOT NULL,
      reservation_time DATETIME NOT NULL,
      duration_minutes INTEGER DEFAULT 60,
      notes TEXT,
      status TEXT DEFAULT 'confirmed',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (table_id) REFERENCES tables(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS daily_notes (
      date TEXT PRIMARY KEY,
      general_notes TEXT DEFAULT '',
      rows_json TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Migrations
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN device_id INTEGER").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN prepaid_minutes INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN is_already_paid INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN billing_mode TEXT").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN deposit_amount REAL").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN device_id INTEGER").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN ps_type TEXT").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN cash_amount REAL DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN card_amount REAL DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN payment_type TEXT DEFAULT 'cash'").run();
  } catch (e) {}

  try {
    db.prepare("ALTER TABLE devices ADD COLUMN separate_report INTEGER DEFAULT 0").run();
  } catch (e) {}

  try {
    db.prepare("ALTER TABLE inventory ADD COLUMN purchase_price REAL DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN is_paused INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN paused_at INTEGER").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN total_paused_minutes INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE inventory ADD COLUMN is_stockless INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE inventory ADD COLUMN original_quantity INTEGER DEFAULT 0").run();
  } catch (e) {}
  
  try {
    db.prepare("ALTER TABLE active_sessions ADD COLUMN extensions_json TEXT DEFAULT '[]'").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN extensions_json TEXT DEFAULT '[]'").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN deleted_from_main INTEGER DEFAULT 0").run();
  } catch (e) {}
  try {
    db.prepare("ALTER TABLE transactions ADD COLUMN deleted_from_separate INTEGER DEFAULT 0").run();
  } catch (e) {}

  // Initialize original_quantity with current stock_quantity for existing items
  try {
    db.prepare("UPDATE inventory SET original_quantity = stock_quantity WHERE original_quantity = 0").run();
  } catch (e) {}

  // Seed default devices if empty
  const deviceCount = db.prepare("SELECT COUNT(*) as count FROM devices").get() as { count: number };
  if (deviceCount.count === 0) {
    const insertDevice = db.prepare("INSERT INTO devices (name, hourly_price) VALUES (?, ?)");
    insertDevice.run("PS3", 2.00);
    insertDevice.run("PS4", 3.00);
    insertDevice.run("PS5", 5.00);
  }

  const seedSettings = [
    { key: 'language', value: 'az' },
    { key: 'admin_password', value: 'MagaPsSystem2026!' },
    { key: 'action_password', value: 'Elgun-96' },
    { key: 'ps3_hourly', value: '2.00' },
    { key: 'ps4_hourly', value: '3.00' },
    { key: 'ps5_hourly', value: '5.00' },
    { key: 'report_password', value: 'Admin123' }
  ];

  const insertSetting = db.prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)");
  seedSettings.forEach(s => insertSetting.run(s.key, s.value));

  // Ensure the password is updated if it was the default or the previous one
  db.prepare("UPDATE settings SET value = ? WHERE key = 'admin_password' AND (value = 'admin123' OR value = 'Magify2026!' OR value = 'Elgun-96')").run("MagaPsSystem2026!");
  db.prepare("UPDATE settings SET value = ? WHERE key = 'action_password' AND (value = 'admin123' OR value = 'MagaPsSystem2026!')").run("Elgun-96");

  // Seed default tables if empty
  const tableCount = db.prepare("SELECT COUNT(*) as count FROM tables").get() as { count: number };
  if (tableCount.count === 0) {
    const insertTable = db.prepare("INSERT INTO tables (name, type, hourly_price) VALUES (?, ?, ?)");
    
    // 4 Kabinet
    for (let i = 1; i <= 4; i++) {
      insertTable.run(`Kabinet ${i}`, "kabinet", 5.00);
    }
    // 10 Tables
    for (let i = 1; i <= 10; i++) {
      insertTable.run(`Table ${i}`, "table", 3.00);
    }
  }

  // Rename existing "Cabin X" to "Kabinet X"
  try {
    db.prepare("UPDATE tables SET name = REPLACE(name, 'Cabin', 'Kabinet') WHERE name LIKE 'Cabin %'").run();
    db.prepare("UPDATE tables SET type = 'kabinet' WHERE type = 'cabin'").run();
  } catch (e) {}

  // Seed default product
  const productCount = db.prepare("SELECT COUNT(*) as count FROM products").get() as { count: number };
  if (productCount.count === 0) {
    db.prepare("INSERT INTO products (name, price, category) VALUES (?, ?, ?)").run("Elave pult", 1.00, "Service");
  }
}

initDb();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ type: ['application/json', 'text/plain'] })); // Some browsers send Beacon with text/plain
  app.use(express.urlencoded({ extended: true }));
  app.use(express.text());

  // --- Auth Routes ---
  app.post("/api/auth/login", (req, res) => {
    const { password, machineId } = req.body;
    const adminPassword = db.prepare("SELECT value FROM settings WHERE key = 'admin_password'").get() as { value: string } | undefined;
    
    if (adminPassword && password === adminPassword.value) {
      const token = crypto.randomBytes(32).toString("hex");
      db.prepare("INSERT INTO auth_sessions (token, machine_id) VALUES (?, ?)").run(token, machineId);
      res.json({ success: true, token });
    } else {
      res.status(401).json({ success: false, message: "Invalid password" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    const { token } = req.body;
    db.prepare("DELETE FROM auth_sessions WHERE token = ?").run(token);
    res.json({ success: true });
  });

  app.post("/api/auth/check", (req, res) => {
    const { token, machineId } = req.body;
    const session = db.prepare("SELECT * FROM auth_sessions WHERE token = ? AND machine_id = ?").get(token, machineId);
    if (session) {
      res.json({ success: true });
    } else {
      res.status(401).json({ success: false });
    }
  });

  // Action Password
  app.post("/api/settings/action-password/verify", (req, res) => {
    const { password } = req.body;
    const actionPassword = db.prepare("SELECT value FROM settings WHERE key = 'action_password'").get() as { value: string } | undefined;
    if (actionPassword && password === actionPassword.value) {
      res.json({ success: true });
    } else {
      res.status(403).json({ success: false });
    }
  });

  app.post("/api/settings/action-password/update", (req, res) => {
    const { currentActionPassword, newActionPassword } = req.body;
    
    const actionPassword = db.prepare("SELECT value FROM settings WHERE key = 'action_password'").get() as { value: string } | undefined;

    if (!actionPassword || currentActionPassword !== actionPassword.value) {
      return res.status(403).json({ success: false, message: "Invalid current action password" });
    }

    db.prepare("UPDATE settings SET value = ? WHERE key = 'action_password'").run(newActionPassword);
    res.json({ success: true });
  });

  app.post("/api/settings/report-password/verify", (req, res) => {
    const { password } = req.body;
    const reportPassword = db.prepare("SELECT value FROM settings WHERE key = 'report_password'").get() as { value: string } | undefined;
    if (reportPassword && password === reportPassword.value) {
      res.json({ success: true });
    } else {
      res.status(403).json({ success: false });
    }
  });

  app.post("/api/settings/report-password/update", (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const reportPassword = db.prepare("SELECT value FROM settings WHERE key = 'report_password'").get() as { value: string } | undefined;

    if (!reportPassword || currentPassword !== reportPassword.value) {
      return res.status(403).json({ success: false, message: "Invalid current report password" });
    }

    db.prepare("UPDATE settings SET value = ? WHERE key = 'report_password'").run(newPassword);
    res.json({ success: true });
  });

  app.post("/api/settings/main-password/verify", (req, res) => {
    const { password } = req.body;
    const adminPassword = db.prepare("SELECT value FROM settings WHERE key = 'admin_password'").get() as { value: string } | undefined;
    if (adminPassword && password === adminPassword.value) {
      res.json({ success: true });
    } else {
      res.status(403).json({ success: false });
    }
  });

  // --- API Routes ---

  // Tables
  app.get("/api/tables", (req, res) => {
    const tables = db.prepare("SELECT * FROM tables").all();
    res.json(tables);
  });

  app.post("/api/tables", (req, res) => {
    const { name, type, hourly_price } = req.body;
    const result = db.prepare("INSERT INTO tables (name, type, hourly_price) VALUES (?, ?, ?)").run(name, type, hourly_price);
    res.json({ id: result.lastInsertRowid, name, type, hourly_price });
  });

  app.put("/api/tables/:id", (req, res) => {
    const { name, type, hourly_price } = req.body;
    db.prepare("UPDATE tables SET name = ?, type = ?, hourly_price = ? WHERE id = ?").run(name, type, hourly_price, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/tables/:id", (req, res) => {
    db.prepare("DELETE FROM tables WHERE id = ?").run(req.params.id);
    db.prepare("DELETE FROM active_sessions WHERE table_id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Devices
  app.get("/api/devices", (req, res) => {
    const devices = db.prepare("SELECT * FROM devices").all();
    res.json(devices);
  });

  app.post("/api/devices", (req, res) => {
    const { name, hourly_price, separate_report } = req.body;
    const result = db.prepare("INSERT INTO devices (name, hourly_price, separate_report) VALUES (?, ?, ?)").run(name, hourly_price, separate_report ? 1 : 0);
    res.json({ id: result.lastInsertRowid, name, hourly_price, separate_report: !!separate_report });
  });

  app.put("/api/devices/:id", (req, res) => {
    const { name, hourly_price, separate_report } = req.body;
    db.prepare("UPDATE devices SET name = ?, hourly_price = ?, separate_report = ? WHERE id = ?").run(name, hourly_price, separate_report ? 1 : 0, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/devices/:id", (req, res) => {
    db.prepare("DELETE FROM devices WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Active Sessions
  app.get("/api/active_sessions", (req, res) => {
    const sessions = db.prepare("SELECT * FROM active_sessions").all();
    const formatted = sessions.map((s: any) => ({
      tableId: s.table_id,
      psType: s.ps_type,
      deviceId: s.device_id,
      startTime: s.start_time,
      type: s.type,
      durationMinutes: s.duration_minutes,
      prepaidMinutes: s.prepaid_minutes,
      isPaused: !!s.is_paused,
      pausedAt: s.paused_at,
      totalPausedMinutes: s.total_paused_minutes,
      isAlreadyPaid: !!s.is_already_paid,
      billingMode: s.billing_mode,
      depositAmount: s.deposit_amount,
      products: JSON.parse(s.products_json || '[]'),
      extensions: JSON.parse(s.extensions_json || '[]')
    }));
    res.json(formatted);
  });

  app.post("/api/active_sessions", (req, res) => {
    const { tableId, psType, deviceId, startTime, type, durationMinutes, prepaidMinutes, products, extensions, isPaused, pausedAt, totalPausedMinutes, isAlreadyPaid, billingMode, depositAmount } = req.body;
    console.log(`Session started for table ${tableId}`);
    db.prepare(`
      INSERT OR REPLACE INTO active_sessions (table_id, ps_type, device_id, start_time, type, duration_minutes, prepaid_minutes, products_json, extensions_json, is_paused, paused_at, total_paused_minutes, is_already_paid, billing_mode, deposit_amount)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      tableId, 
      psType, 
      deviceId || null, 
      startTime, 
      type, 
      durationMinutes, 
      prepaidMinutes || 0, 
      JSON.stringify(products || []),
      JSON.stringify(extensions || []),
      isPaused ? 1 : 0,
      pausedAt || null,
      totalPausedMinutes || 0,
      isAlreadyPaid ? 1 : 0,
      billingMode || null,
      depositAmount || null
    );
    res.json({ success: true });
  });

  app.put("/api/active_sessions/:tableId", (req, res) => {
    const { psType, deviceId, startTime, type, durationMinutes, prepaidMinutes, products, extensions, isPaused, pausedAt, totalPausedMinutes, isAlreadyPaid, billingMode, depositAmount } = req.body;
    db.prepare(`
      UPDATE active_sessions 
      SET ps_type = ?, device_id = ?, start_time = ?, type = ?, duration_minutes = ?, prepaid_minutes = ?, products_json = ?, extensions_json = ?, is_paused = ?, paused_at = ?, total_paused_minutes = ?, is_already_paid = ?, billing_mode = ?, deposit_amount = ?
      WHERE table_id = ?
    `).run(
      psType, 
      deviceId || null, 
      startTime, 
      type, 
      durationMinutes, 
      prepaidMinutes || 0, 
      JSON.stringify(products || []),
      JSON.stringify(extensions || []),
      isPaused ? 1 : 0,
      pausedAt || null,
      totalPausedMinutes || 0,
      isAlreadyPaid ? 1 : 0,
      billingMode || null,
      depositAmount || null,
      req.params.tableId
    );
    res.json({ success: true });
  });

  app.delete("/api/active_sessions/:tableId", (req, res) => {
    console.log(`Session closed manually for table ${req.params.tableId}`);
    db.prepare("DELETE FROM active_sessions WHERE table_id = ?").run(req.params.tableId);
    res.json({ success: true });
  });

  // Products
  app.get("/api/products", (req, res) => {
    const products = db.prepare("SELECT * FROM products").all();
    res.json(products);
  });

  app.post("/api/products", (req, res) => {
    const { name, price, category, inventory_id } = req.body;
    const result = db.prepare("INSERT INTO products (name, price, category, inventory_id) VALUES (?, ?, ?, ?)").run(name, price, category, inventory_id || null);
    res.json({ id: result.lastInsertRowid, name, price, category, inventory_id });
  });

  app.delete("/api/products/:id", (req, res) => {
    db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  app.put("/api/products/:id", (req, res) => {
    const { name, price, category, inventory_id } = req.body;
    db.prepare("UPDATE products SET name = ?, price = ?, category = ?, inventory_id = ? WHERE id = ?").run(name, price, category, inventory_id || null, req.params.id);
    res.json({ success: true });
  });

  // Inventory
  app.get("/api/inventory", (req, res) => {
    const items = db.prepare("SELECT * FROM inventory").all();
    res.json(items);
  });

  app.post("/api/inventory", (req, res) => {
    const { name, stock_quantity, purchase_price, price, is_stockless } = req.body;
    const original_quantity = is_stockless ? 0 : stock_quantity;
    const result = db.prepare("INSERT INTO inventory (name, stock_quantity, original_quantity, purchase_price, price, is_stockless) VALUES (?, ?, ?, ?, ?, ?)").run(name, stock_quantity || 0, original_quantity || 0, purchase_price || 0, price || 0, is_stockless ? 1 : 0);
    res.json({ id: result.lastInsertRowid, name, stock_quantity, purchase_price, price, is_stockless: !!is_stockless });
  });

  app.put("/api/inventory/:id", (req, res) => {
    const { name, stock_quantity, purchase_price, price, is_stockless } = req.body;
    
    // Check if quantity is being changed
    const existing = db.prepare("SELECT stock_quantity FROM inventory WHERE id = ?").get(req.params.id) as any;
    
    if (existing && existing.stock_quantity !== stock_quantity) {
      // If quantity is updated, we reset original_quantity too as per requirement
      db.prepare("UPDATE inventory SET name = ?, stock_quantity = ?, original_quantity = ?, purchase_price = ?, price = ?, is_stockless = ? WHERE id = ?").run(name, stock_quantity || 0, stock_quantity || 0, purchase_price || 0, price || 0, is_stockless ? 1 : 0, req.params.id);
    } else {
      db.prepare("UPDATE inventory SET name = ?, purchase_price = ?, price = ?, is_stockless = ? WHERE id = ?").run(name, purchase_price || 0, price || 0, is_stockless ? 1 : 0, req.params.id);
    }
    res.json({ success: true });
  });

  app.delete("/api/inventory/:id", (req, res) => {
    db.prepare("DELETE FROM inventory WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Product Sets
  app.get("/api/product_sets", (req, res) => {
    const sets = db.prepare("SELECT * FROM product_sets").all();
    const setsWithItems = sets.map((s: any) => {
      const items = db.prepare(`
        SELECT si.*, i.name as inventory_name 
        FROM set_items si 
        JOIN inventory i ON si.inventory_id = i.id 
        WHERE si.set_id = ?
      `).all(s.id);

      const device_time = db.prepare(`
        SELECT sd.*, d.name as device_name
        FROM set_devices sd
        JOIN devices d ON sd.device_id = d.id
        WHERE sd.set_id = ?
      `).all(s.id);

      return { ...s, items, device_time };
    });
    res.json(setsWithItems);
  });

  app.post("/api/product_sets", (req, res) => {
    const { name, total_price, items, device_time } = req.body;
    const transaction = db.transaction(() => {
      const result = db.prepare("INSERT INTO product_sets (name, total_price) VALUES (?, ?)").run(name, total_price);
      const setId = result.lastInsertRowid;
      
      const insertItem = db.prepare("INSERT INTO set_items (set_id, inventory_id, quantity_required) VALUES (?, ?, ?)");
      for (const item of (items || []) as any[]) {
        insertItem.run(setId, item.inventory_id, item.quantity_required);
      }

      const insertDeviceTime = db.prepare("INSERT INTO set_devices (set_id, device_id, included_hours) VALUES (?, ?, ?)");
      for (const dt of (device_time || []) as any[]) {
        insertDeviceTime.run(setId, dt.device_id, dt.included_hours);
      }

      return setId;
    });
    const setId = transaction();
    res.json({ id: setId, name, total_price, items, device_time });
  });

  app.put("/api/product_sets/:id", (req, res) => {
    const { name, total_price, items, device_time } = req.body;
    const transaction = db.transaction(() => {
      db.prepare("UPDATE product_sets SET name = ?, total_price = ? WHERE id = ?").run(name, total_price, req.params.id);
      
      db.prepare("DELETE FROM set_items WHERE set_id = ?").run(req.params.id);
      const insertItem = db.prepare("INSERT INTO set_items (set_id, inventory_id, quantity_required) VALUES (?, ?, ?)");
      for (const item of (items || []) as any[]) {
        insertItem.run(req.params.id, item.inventory_id, item.quantity_required);
      }

      db.prepare("DELETE FROM set_devices WHERE set_id = ?").run(req.params.id);
      const insertDeviceTime = db.prepare("INSERT INTO set_devices (set_id, device_id, included_hours) VALUES (?, ?, ?)");
      for (const dt of (device_time || []) as any[]) {
        insertDeviceTime.run(req.params.id, dt.device_id, dt.included_hours);
      }
    });
    transaction();
    res.json({ success: true });
  });

  app.delete("/api/product_sets/:id", (req, res) => {
    db.prepare("DELETE FROM product_sets WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Settings
  app.get("/api/settings", (req, res) => {
    const settings = db.prepare("SELECT * FROM settings").all();
    const settingsObj = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  });

  app.post("/api/settings", (req, res) => {
    const { settings } = req.body;
    const upsert = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
    for (const [key, value] of Object.entries(settings)) {
      upsert.run(key, String(value));
    }
    res.json({ success: true });
  });

  // Transactions
  app.get("/api/transactions", (req, res) => {
    const { startDate, endDate, reportType } = req.query;
    let query = "SELECT * FROM transactions WHERE 1=1";
    const params: any[] = [];

    if (reportType === 'main') {
      query += " AND deleted_from_main = 0";
    } else if (reportType === 'separate') {
      query += " AND deleted_from_separate = 0";
    }

    if (startDate && endDate) {
      // If contains time part (HH:MM), use as is, otherwise treat as date
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) BETWEEN datetime(?) AND datetime(?)";
      params.push(start, end);
    } else if (startDate) {
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      query += " AND datetime(created_at) >= datetime(?)";
      params.push(start);
    } else if (endDate) {
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) <= datetime(?)";
      params.push(end);
    }

    query += " ORDER BY created_at DESC";
    
    console.log(`Fetching transactions with query: ${query}, params: ${JSON.stringify(params)}`);
    const transactions = db.prepare(query).all(...params);
    res.json(transactions);
  });

  app.post("/api/transactions", (req, res) => {
    const { table_id, table_name, ps_type, device_id, start_time, end_time, duration_minutes, time_cost, product_cost, total_cost, products_json, extensions_json, cash_amount, card_amount, payment_type } = req.body;
    
    const transaction = db.transaction(() => {
      // Insert transaction
      const result = db.prepare(`
        INSERT INTO transactions (table_id, table_name, ps_type, device_id, start_time, end_time, duration_minutes, time_cost, product_cost, total_cost, products_json, extensions_json, cash_amount, card_amount, payment_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(table_id, table_name, ps_type, device_id || null, start_time, end_time, duration_minutes, time_cost, product_cost, total_cost, products_json, extensions_json || '[]', cash_amount || 0, card_amount || 0, payment_type || 'cash');

      // Decrement stock
      const products = JSON.parse(products_json || "[]");
      for (const p of products) {
        if (p.is_set) {
          // It's a product set
          const set_items = db.prepare(`
            SELECT si.*, i.is_stockless 
            FROM set_items si 
            JOIN inventory i ON si.inventory_id = i.id 
            WHERE si.set_id = ?
          `).all(p.set_id);
          for (const item of set_items as any[]) {
            if (!item.is_stockless) {
              db.prepare("UPDATE inventory SET stock_quantity = stock_quantity - ? WHERE id = ?")
                .run(item.quantity_required * p.quantity, item.inventory_id);
            }
          }
        } else if (p.inventory_id) {
          // Check if it's stockless
          const invItem = db.prepare("SELECT is_stockless FROM inventory WHERE id = ?").get(p.inventory_id) as any;
          if (invItem && !invItem.is_stockless) {
            // It's a product linked to inventory
            db.prepare("UPDATE inventory SET stock_quantity = stock_quantity - ? WHERE id = ?")
              .run(p.quantity, p.inventory_id);
          }
        }
      }

      return result.lastInsertRowid;
    });

    const id = transaction();
    res.json({ id });
  });

  app.delete("/api/transactions/:id", (req, res) => {
    const { reportType } = req.query;
    if (reportType === 'main') {
      db.prepare("UPDATE transactions SET deleted_from_main = 1 WHERE id = ?").run(req.params.id);
    } else if (reportType === 'separate') {
      db.prepare("UPDATE transactions SET deleted_from_separate = 1 WHERE id = ?").run(req.params.id);
    } else {
      // Default to hard delete if no reportType specified (backward compatibility or full deletion)
      db.prepare("DELETE FROM transactions WHERE id = ?").run(req.params.id);
    }
    res.json({ success: true });
  });

  app.delete("/api/transactions", (req, res) => {
    const { startDate, endDate, reportType } = req.query;
    let query = "";
    const params: any[] = [];

    if (reportType === 'main') {
      query = "UPDATE transactions SET deleted_from_main = 1 WHERE 1=1";
    } else if (reportType === 'separate') {
      query = "UPDATE transactions SET deleted_from_separate = 1 WHERE 1=1";
    } else {
      query = "DELETE FROM transactions WHERE 1=1";
    }

    if (startDate && endDate) {
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) BETWEEN datetime(?) AND datetime(?)";
      params.push(start, end);
    } else if (startDate) {
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      query += " AND datetime(created_at) >= datetime(?)";
      params.push(start);
    } else if (endDate) {
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) <= datetime(?)";
      params.push(end);
    } else {
      // If no range specified, don't delete anything to comply with "Do NOT delete all data by default"
      // or we can allow it if that's what's intended, but the requirement suggests forcing a range.
      // Let's return error if no range is provided to be safe.
      return res.status(400).json({ success: false, message: "Date range required" });
    }

    db.prepare(query).run(...params);
    res.json({ success: true });
  });

  // Reports
  app.get("/api/reports/inventory-profit", (req, res) => {
    const { startDate, endDate } = req.query;
    
    // Get reset timestamp
    const resetSetting = db.prepare("SELECT value FROM settings WHERE key = 'inventory_profit_reset_at'").get() as any;
    const resetAt = resetSetting ? resetSetting.value : null;

    let query = "SELECT products_json, created_at, payment_type FROM transactions WHERE 1=1";
    const params: any[] = [];

    if (resetAt) {
      query += " AND datetime(created_at) > datetime(?)";
      params.push(resetAt);
    }

    if (startDate && endDate) {
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) BETWEEN datetime(?) AND datetime(?)";
      params.push(start, end);
    } else if (startDate) {
      const start = String(startDate).includes(':') ? startDate : `${startDate} 00:00:00`;
      query += " AND datetime(created_at) >= datetime(?)";
      params.push(start);
    } else if (endDate) {
      const end = String(endDate).includes(':') ? endDate : `${endDate} 23:59:59`;
      query += " AND datetime(created_at) <= datetime(?)";
      params.push(end);
    }

    const transactions = db.prepare(query).all(...params);
    const inventory = db.prepare("SELECT * FROM inventory WHERE is_stockless = 0").all() as any[];
    const products = db.prepare("SELECT p.* FROM products p JOIN inventory i ON p.inventory_id = i.id WHERE i.is_stockless = 0").all() as any[];

    const stats: { [key: number]: any } = {};

    // Initialize stats with all inventory items
    inventory.forEach(item => {
      stats[item.id] = {
        id: item.id,
        name: item.name,
        stock_left: item.stock_quantity,
        original_quantity: item.original_quantity || item.stock_quantity,
        sold_quantity: 0,
        purchase_price: item.purchase_price,
        selling_price: 0, // Will be updated from products or transactions
        revenue: 0,
        profit: 0,
        spent_money: 0
      };
      
      // Find a product linked to this inventory item to get a default selling price
      const linkedProduct = products.find(p => p.inventory_id === item.id);
      if (linkedProduct) {
        stats[item.id].selling_price = linkedProduct.price;
      }
    });

    transactions.forEach((t: any) => {
      const items = JSON.parse(t.products_json || "[]");
      const isUnpaid = t.payment_type === 'unpaid';
      
      items.forEach((p: any) => {
        if (p.is_set) {
          const set_items = db.prepare("SELECT * FROM set_items WHERE set_id = ?").all(p.set_id);
          for (const item of set_items as any[]) {
            if (stats[item.inventory_id]) {
              const qty = item.quantity_required * p.quantity;
              const s = stats[item.inventory_id];
              s.sold_quantity += qty;
              s.spent_money += qty * s.purchase_price;
              
              if (!isUnpaid) {
                s.revenue += qty * s.selling_price;
                s.profit += qty * (s.selling_price - s.purchase_price);
              } else {
                s.profit -= qty * s.purchase_price;
              }
            }
          }
        } else if (p.inventory_id) {
          if (stats[p.inventory_id]) {
            const s = stats[p.inventory_id];
            s.sold_quantity += p.quantity;
            s.spent_money += p.quantity * s.purchase_price;
            
            if (!isUnpaid) {
              s.revenue += p.quantity * p.price;
              s.profit += p.quantity * (p.price - s.purchase_price);
              s.selling_price = p.price;
            } else {
              s.profit -= p.quantity * s.purchase_price;
            }
          }
        }
      });
    });

    res.json(Object.values(stats));
  });

  app.post("/api/reports/inventory-profit/reset", (req, res) => {
    // Use CURRENT_TIMESTAMP to ensure consistency with SQLite's internal time
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('inventory_profit_reset_at', CURRENT_TIMESTAMP)").run();
    const resetSetting = db.prepare("SELECT value FROM settings WHERE key = 'inventory_profit_reset_at'").get() as any;
    res.json({ success: true, resetAt: resetSetting ? resetSetting.value : null });
  });

  app.get("/api/reports/summary", (req, res) => {
    // For main reports, we only count total_cost for sessions on regular devices.
    // For sessions on separate report devices, we only count product_cost in main reports.
    
    const queryDaily = `
      SELECT 
        SUM(CASE 
          WHEN d.separate_report = 1 THEN t.product_cost 
          ELSE t.total_cost 
        END) as total,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.cash_amount < t.product_cost THEN t.cash_amount ELSE t.product_cost END)
          ELSE t.cash_amount 
        END) as cash,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.product_cost - t.cash_amount > 0 THEN t.product_cost - t.cash_amount ELSE 0 END)
          ELSE t.card_amount 
        END) as card
      FROM transactions t
      LEFT JOIN devices d ON t.device_id = d.id
      WHERE date(t.created_at, '+4 hours') = date('now', '+4 hours') 
      AND t.payment_type != 'unpaid'
      AND t.deleted_from_main = 0
    `;

    const queryMonthly = `
      SELECT 
        SUM(CASE 
          WHEN d.separate_report = 1 THEN t.product_cost 
          ELSE t.total_cost 
        END) as total,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.cash_amount < t.product_cost THEN t.cash_amount ELSE t.product_cost END)
          ELSE t.cash_amount 
        END) as cash,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.product_cost - t.cash_amount > 0 THEN t.product_cost - t.cash_amount ELSE 0 END)
          ELSE t.card_amount 
        END) as card
      FROM transactions t
      LEFT JOIN devices d ON t.device_id = d.id
      WHERE strftime('%m', t.created_at, '+4 hours') = strftime('%m', 'now', '+4 hours') 
      AND strftime('%Y', t.created_at, '+4 hours') = strftime('%Y', 'now', '+4 hours') 
      AND t.payment_type != 'unpaid'
      AND t.deleted_from_main = 0
    `;

    const queryTotal = `
      SELECT 
        SUM(CASE 
          WHEN d.separate_report = 1 THEN t.product_cost 
          ELSE t.total_cost 
        END) as total,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.cash_amount < t.product_cost THEN t.cash_amount ELSE t.product_cost END)
          ELSE t.cash_amount 
        END) as cash,
        SUM(CASE 
          WHEN d.separate_report = 1 THEN (CASE WHEN t.product_cost - t.cash_amount > 0 THEN t.product_cost - t.cash_amount ELSE 0 END)
          ELSE t.card_amount 
        END) as card
      FROM transactions t
      LEFT JOIN devices d ON t.device_id = d.id
      WHERE t.payment_type != 'unpaid'
      AND t.deleted_from_main = 0
    `;
    
    const queryLast7Days = `
      SELECT 
        date(t.created_at, '+4 hours') as date, 
        SUM(CASE WHEN d.separate_report = 1 THEN t.product_cost ELSE t.total_cost END) as revenue 
      FROM transactions t
      LEFT JOIN devices d ON t.device_id = d.id
      WHERE date(t.created_at, '+4 hours') >= date('now', '+4 hours', '-6 days') 
      AND t.payment_type != 'unpaid'
      AND t.deleted_from_main = 0
      GROUP BY date(t.created_at, '+4 hours')
      ORDER BY date(t.created_at, '+4 hours') ASC
    `;

    const daily = db.prepare(queryDaily).get() as any;
    const monthly = db.prepare(queryMonthly).get() as any;
    const total = db.prepare(queryTotal).get() as any;
    const last7Days = db.prepare(queryLast7Days).all();
    
    res.json({
      daily: daily?.total || 0,
      dailyCash: daily?.cash || 0,
      dailyCard: daily?.card || 0,
      monthly: monthly?.total || 0,
      monthlyCash: monthly?.cash || 0,
      monthlyCard: monthly?.card || 0,
      total: total?.total || 0,
      totalCash: total?.cash || 0,
      totalCard: total?.card || 0,
      chartData: last7Days
    });
  });

  app.post("/api/settings/admin-password/update", (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const adminPassword = db.prepare("SELECT value FROM settings WHERE key = 'admin_password'").get() as { value: string } | undefined;
    
    if (!adminPassword || currentPassword !== adminPassword.value) {
      return res.status(401).json({ error: "Current password incorrect" });
    }

    db.prepare("UPDATE settings SET value = ? WHERE key = 'admin_password'").run(newPassword);
    res.json({ success: true });
  });

  // Helper to check for reservation conflicts (Double booking prevention)
  const hasReservationConflict = (tableId: number, startTimeStr: string, durationMinutes: number, excludeId?: number) => {
    const newStart = new Date(startTimeStr).getTime();
    const newEnd = newStart + (durationMinutes || 60) * 60000;

    const query = excludeId 
      ? db.prepare("SELECT * FROM reservations WHERE table_id = ? AND status != 'cancelled' AND id != ?").all(tableId, excludeId)
      : db.prepare("SELECT * FROM reservations WHERE table_id = ? AND status != 'cancelled'").all(tableId);

    for (const res of query as any[]) {
      const existingStart = new Date(res.reservation_time).getTime();
      const existingEnd = existingStart + (res.duration_minutes || 60) * 60000;

      // Overlap condition
      if (newStart < existingEnd && newEnd > existingStart) {
        return res;
      }
    }
    return null;
  };

  // Reservations Endpoints
  app.get("/api/reservations", (req, res) => {
    const reservations = db.prepare(`
      SELECT r.*, t.name as table_name, t.type as table_type 
      FROM reservations r
      LEFT JOIN tables t ON r.table_id = t.id
      ORDER BY r.reservation_time ASC
    `).all();
    res.json(reservations);
  });

  app.post("/api/reservations", (req, res) => {
    const { customer_name, customer_phone, table_id, reservation_time, duration_minutes, notes, status } = req.body;
    
    if (!customer_name || !table_id || !reservation_time) {
      return res.status(400).json({ error: "Missing required reservation fields" });
    }

    const duration = duration_minutes ? parseInt(duration_minutes, 10) : 60;
    const conflict = hasReservationConflict(table_id, reservation_time, duration);
    if (conflict) {
      return res.status(409).json({ 
        error: "DOUBLE_BOOKING", 
        message: "Bu masa/kabinet qeyd olunan vaxtda artıq rezerv edilib.",
        conflictingReservation: conflict 
      });
    }

    const result = db.prepare(`
      INSERT INTO reservations (customer_name, customer_phone, table_id, reservation_time, duration_minutes, notes, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      customer_name,
      customer_phone || null,
      table_id,
      reservation_time,
      duration,
      notes || null,
      status || 'confirmed'
    );

    res.json({ id: result.lastInsertRowid, success: true });
  });

  app.put("/api/reservations/:id", (req, res) => {
    const { id } = req.params;
    const { customer_name, customer_phone, table_id, reservation_time, duration_minutes, notes, status } = req.body;

    if (!customer_name || !table_id || !reservation_time) {
      return res.status(400).json({ error: "Missing required reservation fields" });
    }

    const duration = duration_minutes ? parseInt(duration_minutes, 10) : 60;
    if (status !== 'cancelled') {
      const conflict = hasReservationConflict(table_id, reservation_time, duration, parseInt(id, 10));
      if (conflict) {
        return res.status(409).json({ 
          error: "DOUBLE_BOOKING", 
          message: "Bu masa/kabinet qeyd olunan vaxtda artıq rezerv edilib.",
          conflictingReservation: conflict 
        });
      }
    }

    db.prepare(`
      UPDATE reservations 
      SET customer_name = ?, customer_phone = ?, table_id = ?, reservation_time = ?, duration_minutes = ?, notes = ?, status = ?
      WHERE id = ?
    `).run(
      customer_name,
      customer_phone || null,
      table_id,
      reservation_time,
      duration,
      notes || null,
      status || 'confirmed',
      id
    );

    res.json({ success: true });
  });

  app.delete("/api/reservations/:id", (req, res) => {
    const { id } = req.params;
    db.prepare("DELETE FROM reservations WHERE id = ?").run(id);
    res.json({ success: true });
  });

  // --- Daily Notes Endpoints ---
  app.get("/api/daily-notes", (req, res) => {
    const { date } = req.query;
    if (!date || typeof date !== "string") {
      return res.status(400).json({ error: "Date parameter is required (YYYY-MM-DD)" });
    }

    const row = db.prepare("SELECT * FROM daily_notes WHERE date = ?").get(date) as any;
    if (!row) {
      return res.json({
        date,
        general_notes: "",
        rows: [],
        updated_at: null
      });
    }

    let parsedRows: any[] = [];
    try {
      parsedRows = JSON.parse(row.rows_json || "[]");
    } catch (e) {
      parsedRows = [];
    }

    res.json({
      date: row.date,
      general_notes: row.general_notes || "",
      rows: parsedRows,
      updated_at: row.updated_at
    });
  });

  app.post("/api/daily-notes", (req, res) => {
    const { date, general_notes, rows } = req.body;
    if (!date || typeof date !== "string") {
      return res.status(400).json({ error: "Date is required (YYYY-MM-DD)" });
    }

    const rowsJson = JSON.stringify(Array.isArray(rows) ? rows : []);
    const notesText = typeof general_notes === "string" ? general_notes : "";

    const upsert = db.prepare(`
      INSERT INTO daily_notes (date, general_notes, rows_json, updated_at)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(date) DO UPDATE SET
        general_notes = excluded.general_notes,
        rows_json = excluded.rows_json,
        updated_at = CURRENT_TIMESTAMP
    `);

    upsert.run(date, notesText, rowsJson);

    res.json({
      success: true,
      date,
      general_notes: notesText,
      rows: Array.isArray(rows) ? rows : [],
      updated_at: new Date().toISOString()
    });
  });

  app.get("/api/daily-notes/history", (req, res) => {
    const history = db.prepare(`
      SELECT 
        date,
        updated_at,
        length(general_notes) as notes_length,
        rows_json
      FROM daily_notes
      ORDER BY date DESC
      LIMIT 120
    `).all();

    const formatted = history.map((item: any) => {
      let rowCount = 0;
      try {
        const rows = JSON.parse(item.rows_json || "[]");
        rowCount = Array.isArray(rows) ? rows.length : 0;
      } catch (e) {
        rowCount = 0;
      }
      return {
        date: item.date,
        updated_at: item.updated_at,
        notes_length: item.notes_length || 0,
        row_count: rowCount,
        has_content: (item.notes_length || 0) > 0 || rowCount > 0
      };
    });

    res.json(formatted);
  });

  app.delete("/api/daily-notes", (req, res) => {
    const { date } = req.query;
    if (!date || typeof date !== "string") {
      return res.status(400).json({ error: "Date parameter is required" });
    }
    db.prepare("DELETE FROM daily_notes WHERE date = ?").run(date);
    res.json({ success: true });
  });

  // --- Vite / Static Files ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    // No longer logging app opened here, moving to client-side for better reliability
  });

  // Server-side exit handling is now purely for process logging if needed
  const handleExit = (signal?: string) => {
    if (signal) {
      console.log(`Server process exiting (Signal: ${signal})`);
      process.exit(0);
    }
  };

  process.on('SIGTERM', () => handleExit('SIGTERM'));
  process.on('SIGINT', () => handleExit('SIGINT'));
  process.on('SIGUSR2', () => handleExit('SIGUSR2'));
  process.on('exit', () => handleExit());
}

startServer();
